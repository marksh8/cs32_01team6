#include "stdafx.h"
#include "CppUnitTest.h"
#include "FileParser.h"
#include "QueryParser.h"
#include "ProgramKnowledgeBase.h"
#include <sstream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace IntegretionTest
{		
	TEST_CLASS(UnitTest1)
	{
	private:
		QueryParser qp;

		inline std::string resToStr(std::list<std::string> res) {
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			switch (res.size())
			{
			case 0:
				return std::string();
			case 1:
				return res.front();
			default:
				std::stringstream oss;
				std::for_each(res.begin(), --res.end(), [&oss](std::string str) {
					oss << str << ", ";
				});
				oss << res.back();
				return oss.str();
			}
			
		}
	public:
		TEST_CLASS_INITIALIZE(init) {
			auto& pkb = ProgramKnowledgeBase::getInstance();
			pkb.clean();
			//assume parser and pkb are tested
			FileParser("../tests/Sample-Source.txt").parse();
		}
		TEST_METHOD(Inte1)
		{
			qp.parseQuery("while w; variable v; Select w such that Modifies(w, v) with v.varName = \"x\"");
			//qp.parseQuery("variable v; Select v with v.varName = \"x\"");
			auto res = qp.queryResult();
			std::string expected = "4, 14";
			Assert::AreEqual(expected, resToStr(res), false);
		}
		TEST_METHOD(Inte2)
		{
			qp.parseQuery("if ifs; assign a1, a2; variable v1, v2; Select ifs such that Follows*(a1, ifs) and Follows*(ifs, a2) and Modifies(ifs, v1) and Uses(ifs, v2) with v1.varName = v2.varName");
			auto res = qp.queryResult();
			std::string expected = "6";
			Assert::AreEqual(expected, resToStr(res), false);
		}
		TEST_METHOD(Inte3)
		{
			qp.parseQuery("prog_line n; assign a; Select a such that Affects*(a, n) and Next*(13, n)");
			auto res = qp.queryResult();
			std::string expected = "17, 18, 19, 20";
			Assert::AreEqual(expected, resToStr(res), false);
		}
		TEST_METHOD(Inte4)
		{
			qp.parseQuery("procedure p, q; Select BOOLEAN such that Calls(p, q) with q.procName = \"p\" and p.procName = \"Example\"");
			auto res = qp.queryResult();
			std::string expected = "true";
			Assert::AreEqual(expected, resToStr(res), false);
		}
		TEST_METHOD(Inte7)
		{
			qp.parseQuery("assign a1, a2; variable v; Select v pattern a1(v, _) such that Affects*(a1, a2) and Uses(a2, v)");
			auto res = qp.queryResult();
			std::string expected = "i, x, z";
			Assert::AreEqual(expected, resToStr(res), false);
		}
	};
}