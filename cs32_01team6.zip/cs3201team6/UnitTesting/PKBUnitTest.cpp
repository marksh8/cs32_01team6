#include "stdafx.h"
#include "CppUnitTest.h"
#include "ProgramKnowledgeBase.h"
#include "Procedure.h"
#include "Statement.h"
#include "stmt_type.h"
#include "FileParser.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace PKBUnitTest
{
	TEST_CLASS(UnitTest1)
	{
	public:
		ProgramKnowledgeBase& pkb = ProgramKnowledgeBase::getInstance();
		TEST_METHOD(BuildPKB)
		{
			pkb.clean();
			pkb.addProcedure("apple");
			pkb.addAssign("x", { "t" }, "t");
			pkb.addAssign("y", { "x" }, "x");
			pkb.addWhile("s");
			pkb.addAssign("z", { "y" }, "y");
			pkb.addCall("short");
			pkb.addAssign("u", { "x","y","z" }, "x+y+z");
			pkb.addIf("p");
			pkb.addAssign("x", { "u" }, "u");
			pkb.addIf("q");
			pkb.addAssign("z", { "y" }, "y");
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addAssign("z", { "x" }, "x");
			pkb.rightBracket();
			pkb.addAssign("y", { "z" }, "z");
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addWhile("y");
			pkb.addAssign("x", { "x" }, "x");
			pkb.rightBracket();
			pkb.rightBracket();
			pkb.rightBracket();
			pkb.addAssign("z", { "x" }, "x");
			pkb.addCall("loop");
			pkb.addProcedure("short");
			pkb.addIf("z");
			pkb.addAssign("z", { "z" }, "z");
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addAssign("z", { "m" }, "m");
			pkb.rightBracket();
			pkb.addProcedure("loop");
			pkb.addWhile("x");
			pkb.addAssign("a", { "b" }, "b");
			pkb.addAssign("b", { "c" }, "c");
			pkb.addAssign("c", { "d" }, "d");
			pkb.addAssign("d", { "a" }, "a");
			pkb.rightBracket();
			pkb.addCall("deeploop");
			pkb.addProcedure("deeploop");
			pkb.addWhile("w");
			pkb.addAssign("h", { "i" }, "i");
			pkb.addWhile("w");
			pkb.addAssign("i", { "j" }, "j");
			pkb.addWhile("w");
			pkb.addAssign("j", { "k" }, "k");
			pkb.addWhile("w");
			pkb.addAssign("k", { "h" }, "h");
			pkb.rightBracket();
			pkb.rightBracket();
			pkb.rightBracket();
			pkb.rightBracket();

			Assert::IsTrue(true, false);
		}
		TEST_METHOD(PKBTestFollow)
		{
			Assert::IsTrue(pkb.isFollow(1, 2), false);
			Assert::IsTrue(pkb.isFollow(3, 15), false);
			Assert::IsFalse(pkb.isFollow(2, 1), false);
			Assert::IsFalse(pkb.isFollow(1, 3), false);
			Assert::IsFalse(pkb.isFollow(3, 4), false);
			Assert::IsFalse(pkb.isFollow(10, 11), false);
		}
		TEST_METHOD(PKBTestFollowS)
		{
			Assert::IsTrue(pkb.isFollowS(1, 3), false);
			Assert::IsTrue(pkb.isFollowS(8, 12), false);
			Assert::IsTrue(pkb.isFollowS(1, 15), false);
			Assert::IsFalse(pkb.isFollowS(1, 4), false);
			Assert::IsFalse(pkb.isFollowS(4, 8), false);
		}
		TEST_METHOD(PKBTestParent)
		{
			Assert::IsTrue(pkb.isParent(3, 4), false);
			Assert::IsTrue(pkb.isParent(7, 8), false);
			Assert::IsTrue(pkb.isParent(7, 13), false);
			Assert::IsFalse(pkb.isParent(1, 2), false);
			Assert::IsFalse(pkb.isParent(4, 3), false);
			Assert::IsFalse(pkb.isParent(3, 8), false);
			Assert::IsFalse(pkb.isParent(7, 10), false);
		}
		TEST_METHOD(PKBTestParentS)
		{
			Assert::IsTrue(pkb.isParentS(3, 4), false);
			Assert::IsTrue(pkb.isParentS(7, 8), false);
			Assert::IsTrue(pkb.isParentS(3, 8), false);
			Assert::IsTrue(pkb.isParentS(7, 10), false);
			Assert::IsTrue(pkb.isParentS(3, 14), false);
			Assert::IsTrue(pkb.isParentS(26, 33), false);
			Assert::IsFalse(pkb.isParentS(3, 18), false);
		}
		TEST_METHOD(PKBTestCall)
		{
			Assert::IsTrue(pkb.isCall("apple", "short"), false);
			Assert::IsTrue(pkb.isCall("apple", "loop"), false);
			Assert::IsFalse(pkb.isCall("apple", "deeploop"), false);
			Assert::IsFalse(pkb.isCall("short", "apple"), false);
		}
		TEST_METHOD(PKBTestCallS)
		{
			Assert::IsTrue(pkb.isCallS("apple", "loop"), false);
			Assert::IsTrue(pkb.isCallS("apple", "deeploop"), false);
			Assert::IsFalse(pkb.isCallS("deeploop","apple"), false);
		}
		TEST_METHOD(PKBTestUses)
		{
			std::string res = pkb.printStringSet(pkb.allVarUsesP("apple"));
			Assert::AreEqual(res, std::string("a b c d h i j k m p q s t u w x y z"), false);
			Assert::IsTrue(pkb.isUsesS(1, "t"));
			res = pkb.printStringSet(pkb.allVarUsesS(3));
			Assert::AreEqual(res, std::string("m p q s u x y z"));
			res = pkb.printStringSet(pkb.allVarUsesS(6));
			Assert::AreEqual(res, std::string("x y z"));
			res = pkb.printStringSet(pkb.allVarUsesS(7));
			Assert::AreEqual(res, std::string("p q u x y z"));
			res = pkb.printStringSet(pkb.allVarUsesS(26));
			Assert::AreEqual(res, std::string("h i j k w"));
		}
		TEST_METHOD(PKBTestModifies)
		{
			std::string res = pkb.printStringSet(pkb.allVarModifiesP("apple"));
			Assert::AreEqual(res, std::string("a b c d h i j k u x y z"), false);
			Assert::IsTrue(pkb.isModifiesS(1, "x"));
			res = pkb.printStringSet(pkb.allVarModifiesS(3));
			Assert::AreEqual(res, std::string("u x y z"));
			res = pkb.printStringSet(pkb.allVarModifiesS(7));
			Assert::AreEqual(res, std::string("x y z"));
			res = pkb.printStringSet(pkb.allVarModifiesS(26));
			Assert::AreEqual(res, std::string("h i j k"));
		}
		TEST_METHOD(PKBTestNext)
		{
			Assert::IsTrue(pkb.isNext(1, 2));
			Assert::IsTrue(pkb.isNext(3, 4));
			Assert::IsTrue(pkb.isNext(3, 15));
			Assert::IsTrue(pkb.isNext(13, 3));
			Assert::IsTrue(pkb.isNext(12, 3));
			Assert::IsTrue(pkb.isNext(10, 12));
			Assert::IsTrue(pkb.isNext(11, 12));
			Assert::IsFalse(pkb.isNext(2, 1));
			Assert::IsFalse(pkb.isNext(3, 3));
			Assert::IsFalse(pkb.isNext(14, 3));
			Assert::IsFalse(pkb.isNext(10, 11));
			Assert::IsFalse(pkb.isNext(7, 3));
		}
		TEST_METHOD(PKBTestNextS)
		{
			Assert::IsTrue(pkb.isNextS(1, 2));
			Assert::IsTrue(pkb.isNextS(3, 3));
			Assert::IsTrue(pkb.isNextS(11, 10));
			Assert::IsTrue(pkb.isNextS(14, 14));
			Assert::IsTrue(pkb.isNextS(7, 11));
			Assert::IsTrue(pkb.isNextS(6, 5));
			Assert::IsTrue(pkb.isNextS(33, 27));
			Assert::IsFalse(pkb.isNextS(15, 3));
			Assert::IsFalse(pkb.isNextS(18, 19));
			Assert::IsFalse(pkb.isNextS(17, 17));
		}
		TEST_METHOD(PKBTestAffect)
		{
			Assert::IsTrue(pkb.isAffect(1, 2));
			Assert::IsTrue(pkb.isAffect(2, 4));
			Assert::IsTrue(pkb.isAffect(14, 14));
			Assert::IsFalse(pkb.isAffect(4, 6));
			Assert::IsFalse(pkb.isAffect(18, 18));
		}
		TEST_METHOD(PKBTestAffectS)
		{
			Assert::IsTrue(pkb.isAffectS(1, 2));
			Assert::IsTrue(pkb.isAffectS(2, 4));
			Assert::IsTrue(pkb.isAffectS(24, 21));
			Assert::IsTrue(pkb.isAffectS(33, 27));
			Assert::IsFalse(pkb.isAffectS(4, 6));
		}
		TEST_METHOD(PKBTestAffectSIfInWhile)
		{
			Assert::IsTrue(pkb.isAffectS(6, 12));
		}
		TEST_METHOD(PKBTestAllNextStmts)
		{
			std::string res = pkb.printIntSet(pkb.allNextStmts(13));
			Assert::AreEqual(res, std::string("3 14"), false);
			res = pkb.printIntSet(pkb.allNextStmts(7));
			Assert::AreEqual(res, std::string("8 13"), false);
		}
		TEST_METHOD(PKBTestAllPrevStmts)
		{
			std::string res = pkb.printIntSet(pkb.allPrevStmts(3));
			Assert::AreEqual(res, std::string("2 12 13"), false);
		}
		TEST_METHOD(PKBTestAllNextSStmts)
		{
			std::string res = pkb.printIntSet(pkb.allNextSStmts(3));
			Assert::AreEqual(res, std::string("3 4 5 6 7 8 9 10 11 12 13 14 15 16"), false);
		}
		TEST_METHOD(PKBTestAllPrevSStmts)
		{
			std::string res = pkb.printIntSet(pkb.allPrevSStmts(25));
			Assert::AreEqual(res, std::string("20 21 22 23 24"), false);
		}
		TEST_METHOD(PKBTestAllAffectStmts)
		{
			std::string res = pkb.printIntSet(pkb.allAffectStmts(2));
			Assert::AreEqual(res, std::string("4 6 10"), false);
			res = pkb.printIntSet(pkb.allAffectStmts(33));
			Assert::AreEqual(res, std::string("31"), false);
			res = pkb.printIntSet(pkb.allAffectStmts(27));
			Assert::AreEqual(res, std::string("33"), false);
		}
		TEST_METHOD(PKBTestAllAffectedStmts)
		{
			std::string res = pkb.printIntSet(pkb.allAffectedStmts(12));
			Assert::AreEqual(res, std::string("10 11"), false);
		}
		TEST_METHOD(PKBTestAllAffectedStmts2)
		{
			pkb.clean();
			pkb.addProcedure("apple");
			pkb.addWhile("x");
			pkb.addAssign("a", { "b" }, "b");
			pkb.addAssign("b", { "c" }, "c");
			pkb.addAssign("x", { "a", "b", "c", "d"}, "a+b+c+d");
			pkb.addAssign("c", { "d" }, "d");
			pkb.addAssign("d", { "e" }, "e");
			pkb.addAssign("d", { "a" }, "a");
			pkb.rightBracket();

			std::string res = pkb.printIntSet(pkb.allAffectedStmts(4));
			Assert::AreEqual(res, std::string("2 3 5 7"), false);
		}

		TEST_METHOD(PKBTestAffectSIfInWhileRepeatLoop)
		{
			pkb.clean();
			pkb.addProcedure("apple");
			pkb.addWhile("x");
			pkb.addIf("x");
			pkb.addAssign("a", { "b" }, "b");
			pkb.beginElse();
			pkb.addAssign("b", { "c" }, "c");
			pkb.rightBracket();
			pkb.addIf("x");
			pkb.addAssign("c", { "d" }, "d");
			pkb.beginElse();
			pkb.addAssign("d", { "a" }, "a");
			pkb.rightBracket();
			pkb.rightBracket();
			Assert::IsTrue(pkb.isAffectS(7, 3));
		}
		TEST_METHOD(PKBTestSelfAssignCascade)
		{
			pkb.clean();
			pkb.addProcedure("apple");
			pkb.addWhile("x");
			pkb.addAssign("x", { "x" }, "x");
			pkb.addAssign("x", { "y" }, "y");
			pkb.rightBracket();
			Assert::IsFalse(pkb.isAffect(2, 2));
		}
		TEST_METHOD(PKBTestAffectSStmts)
		{
			pkb.clean();
			pkb.addProcedure("apple");
			pkb.addWhile("x");
			pkb.addIf("x");
			pkb.addAssign("a", { "b" }, "b");
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addAssign("b", { "c" }, "c");
			pkb.rightBracket();
			pkb.addIf("x");
			pkb.addAssign("c", { "d" }, "d");
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addAssign("d", { "a" }, "a");
			pkb.rightBracket();
			pkb.rightBracket();
			std::string res = pkb.printIntSet(pkb.allAffectSStmts(7));
			Assert::AreEqual(res, std::string("3 4 6 7"), false);
		}
		TEST_METHOD(PKBTestAffectSStmtsSimple)
		{
			pkb.clean();
			pkb.addProcedure("apple");
			pkb.addWhile("x");
			pkb.addAssign("a", { "b" }, "b");
			pkb.addAssign("b", { "c" }, "c");
			pkb.addAssign("c", { "d" }, "d");
			pkb.addAssign("d", { "a" }, "a");
			pkb.rightBracket();
			std::string res = pkb.printIntSet(pkb.allAffectSStmts(5));
			Assert::AreEqual(res, std::string("2 3 4 5"), false);
		}
		TEST_METHOD(PKBTestAffectSNestIf)
		{
			pkb.clean();
			pkb.addProcedure("apple");
			pkb.addWhile("x");
			pkb.addIf("x");
			pkb.addIf("x");
			pkb.addAssign("a", { "b" }, "b");
			pkb.addAssign("c", { "d" }, "d");
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addAssign("b", { "c" }, "c");
			pkb.rightBracket();
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addIf("x");
			pkb.addAssign("c", { "d" }, "d");
			pkb.rightBracket();
			pkb.beginElse();
			pkb.addAssign("d", { "a" }, "a");
			pkb.rightBracket();
			pkb.rightBracket();
			pkb.rightBracket();
			std::string res = pkb.printIntSet(pkb.allAffectSStmts(9));
			Assert::AreEqual(res, std::string("4 5 6 8 9"), false);
		}
	};
}