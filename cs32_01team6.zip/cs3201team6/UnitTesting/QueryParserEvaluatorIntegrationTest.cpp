#include "stdafx.h"
#include "CppUnitTest.h"
#include "QueryParser.h"
#include "QueryEvaluator.h"
#include "ProgramKnowledgeBase.h"

//for debug
#include "FileParser.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace QueryParserEvaluatorIntegrationTest
{
	TEST_CLASS(UnitTest1)
	{
	public:
		TEST_CLASS_INITIALIZE(init) {
			auto& pkb = ProgramKnowledgeBase::getInstance();
			pkb.clean();
			//assume parser and pkb are tested
			FileParser("../Sample.txt").parse();
		}
		TEST_METHOD(InteTestParentProcess1)
		{
			//"stmt s; Select s such that Parent*(4,s)";
			QueryParser parser = QueryParser();
			parser.parseQuery("stmt s; Select s such that Parent*(4,s)");
			
			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;

			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();

			std::string expected = "5 6 7 8 9";

			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestParentProcess2)
		{
			//"assign a; while w; Select a such that Parent(w, a) "
			QueryParser parser = QueryParser();
			parser.parseQuery("assign a; while w; Select a such that Parent(w, a)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "5 7 8 9 11 12 13 14 16 18 20 22";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestFollowsProcess1)
		{
			//"stmt s; Select s such that Follows*(5, s)"
			QueryParser parser = QueryParser();
			parser.parseQuery("stmt s; Select s such that Follows*(5, s)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "6 9";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestFollowsProcess2)
		{
			//"stmt s; Select s such that Follows*(s, 9)"
			QueryParser parser = QueryParser();
			parser.parseQuery("stmt s; Select s such that Follows*(s, 9)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "5 6";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestUsesProcess1)
		{
			//"stmt s; Select s such that Uses(s, \"z\")"
			QueryParser parser = QueryParser();
			parser.parseQuery("stmt s; Select s such that Uses(s, \"z\")");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "2 3 4 6 7 9";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestUsesProcess2)
		{
			//"procedure p; Select p such that Uses(p, \"z\")"
			QueryParser parser = QueryParser();
			parser.parseQuery("procedure p; Select p such that Uses(p, \"z\")");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "apple";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestUsesProcess3)
		{
			//"variable v; Select v such that Uses(7, v)"
			QueryParser parser = QueryParser();
			parser.parseQuery("variable v; Select v such that Uses(7, v)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "w x z";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestModifiesProcess1)
		{
			//"stmt s; Select s such that Modifies(s, \"x\")"
			QueryParser parser = QueryParser();
			parser.parseQuery("stmt s; Select s such that Modifies(s, \"x\")");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "1 4 6 8";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestModifiesProcess2)
		{
			//"procedure p; Select p such that Modifies(p, \"x\")"
			QueryParser parser = QueryParser();
			parser.parseQuery("procedure p; Select p such that Modifies(p, \"x\")");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "apple";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestModifiesProcess3)
		{
			//"variable v; Select v such that Modifies(4, v)"
			QueryParser parser = QueryParser();
			parser.parseQuery("variable v; Select v such that Modifies(4, v)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "t x y";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestPatternProcess1)
		{
			//"assign a; Select a pattern a(_, _\"x+z\"_)"
			QueryParser parser = QueryParser();
			parser.parseQuery("assign a; Select a pattern a(_, _\"x+z\"_)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "3 7";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestPatternProcess2)
		{
			//"assign a; Select a pattern a(\"x\", _)"
			QueryParser parser = QueryParser();
			parser.parseQuery("assign a; Select a pattern a(\"x\", _)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "1 8";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestPatternProcess3)
		{
			//"variable v; assign a; while w; Select w such that Uses(w, v) pattern a (v, _)");
			QueryParser parser = QueryParser();
			parser.parseQuery("variable v; assign a; while w; Select w such that Uses(w, v) pattern a (v, _)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "4 6 10 15 17 19 21";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(InteTestPatternProcess4)
		{
			//"variable v; assign a; Select a such that Uses(a, v) pattern a (v, _)");
			QueryParser parser = QueryParser();
			parser.parseQuery("variable v; assign a; Select a such that Uses(a, v) pattern a (v, _)");

			QueryEvaluator evaluator;
			auto selected = parser.getSelectList();
			auto clauses = parser.getClausesList();

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "1 2";
			Assert::AreEqual(resstring, expected, false);
		}
	};
}