#include "stdafx.h"
#include "CppUnitTest.h"
#include "QueryParser.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace QueryParserTest
{
	TEST_CLASS(UnitTest1)
	{
	public:

		TEST_METHOD(TestQuery) 
		{
			QueryParser test;
			test.parseQuery("call c; if ifs; while w; Select BOOLEAN such that Next*(ifs, c) and Next*(w, c) pattern w(\"y\", _) and ifs(\"q\", _, _)");
			Assert::IsTrue(test.getIsValidQuery());
			
		}

		TEST_METHOD(TestRegex)
		{
			// TODO: Your test code here
			QueryParser test;
			std::string IDENT = "[A-Za-z]([A-Za-z]|[0-9]|#)*";
			std::string parseR2 = "Select BOOLEAN|Select " + IDENT + "|Select <\\s?(" + IDENT + "\\s?,\\s?)+" + IDENT + "\\s?>";
			std::string parseR3 = "Select BOOLEAN .+|Select " + IDENT + " .+";
			std::string parseR4 = "Select <\\s?(" + IDENT + "\\s?,\\s?)+" + IDENT + "\\s?> .+";
			//test select
			Assert::IsFalse(test.testRegex("Select 12", parseR2));
			Assert::IsTrue(test.testRegex("Select BOOLEAN such that parent(1,2)", parseR3));
			Assert::IsTrue(test.testRegex("Select a123", parseR2));
			Assert::IsFalse(test.testRegex("Select a1,a2", parseR2));
			Assert::IsTrue(test.testRegex("Select a123 such that Parent(12,2)", parseR3));
			Assert::IsTrue(test.testRegex("Select <a,b>", parseR2));
			Assert::IsFalse(test.testRegex("Select <a>", parseR2));
			Assert::IsTrue(test.testRegex("Select <abc, bc,ddee>", parseR2));
			Assert::IsFalse(test.testRegex("Select a,b>", parseR2));
			Assert::IsFalse(test.testRegex("Select a,b", parseR2));
			Assert::IsTrue(test.testRegex("Select <a,b> such that parent(1,2)", parseR4));


			//for parsing relationships/pattern
			std::string stmtRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|([0-9])+)";
			std::string lineRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|([0-9])+)";
			std::string entRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|\"" + IDENT + "\"|([0-9])+)";
			std::string varRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|\"" + IDENT + "\")";
			std::string expressionSpec = "((\"\\s?((\\w+\\s?(\\+|\\*|-)\\s?)*\\w+)\\s?\")|(_\\s?\"\\s?((\\w+\\s?(\\+|\\*|-)\\s?)*\\w+)\\s?\"\\s?_))";

			std::string followsParent = "(Follows\\s?(\\*)?|Parent\\s?(\\*)?)\\s?\\(\\s?" + stmtRef + "\\s?,\\s?" + stmtRef + "\\s?\\)";
			std::string usesModifies = "(Uses|Modifies)\\s?\\(\\s?(" + entRef + "|" + stmtRef + ")\\s?,\\s?" + varRef + "\\s?\\)";
			std::string calls = "Calls\\s?(\\*)?\\s?\\(\\s?" + entRef + "\\s?,\\s?" + entRef + "\\s?\\)";
			std::string next = "Next\\s?(\\*)?\\s?\\(\\s?" + lineRef + "\\s?,\\s?" + lineRef + "\\s?\\)";
			std::string relRef = "(" + followsParent + "|" + usesModifies + "|" + calls + "|" + next + ")";
			std::string suchThat = "such that " + relRef + "( and " + relRef + ")*";

			std::string pattern = IDENT + "\\s?\\(\\s?" + varRef + "\\s?,\\s?(" + expressionSpec + "|_)\\s?(,\\s?_\\s?)?\\)";
			std::string patternCond = "pattern " + pattern + "( and " + pattern + ")*";

			std::string attrName = "(procName|varName|value|stmt#)";
			std::string attrRef = IDENT + "\\s?\\.\\s?" + attrName;
			std::string ref = "(" + attrRef + "|" + IDENT + "|\"" + IDENT + "\"|([0-9])+)";
			std::string attrCompare = ref + "\\s?=\\s?" + ref;
			std::string attrCond = "with " + attrCompare + "( and " + attrCompare + ")*";

			Assert::IsTrue(test.testRegex("ab.procName", attrRef));
			Assert::IsTrue(test.testRegex("ab . varName", attrRef));
			Assert::IsTrue(test.testRegex("ab. value", attrRef));
			Assert::IsTrue(test.testRegex("ab .stmt#", attrRef));
			Assert::IsFalse(test.testRegex("ab value", attrRef));
			Assert::IsFalse(test.testRegex("1.value", attrRef));

			Assert::IsTrue(test.testRegex("ab.procName = \"first\"", attrCompare));
			Assert::IsTrue(test.testRegex("ab.varName= \"first\"", attrCompare));
			Assert::IsTrue(test.testRegex("ab.value =3", attrCompare));
			Assert::IsTrue(test.testRegex("ab.stmt#=22", attrCompare));
			Assert::IsTrue(test.testRegex("ab.stmt#=bb", attrCompare));
			Assert::IsTrue(test.testRegex("ab.stmt#=bb.value", attrCompare));
			Assert::IsFalse(test.testRegex("ab.stmt# bb.value", attrCompare));
			Assert::IsFalse(test.testRegex("ab.stmt# == bb.value", attrCompare));

			Assert::IsTrue(test.testRegex("with ab.procName = \"first\" and ab.value =3 and b.varName = \"se\"", attrCond));
			Assert::IsTrue(test.testRegex("with ab.procName = \"first\"", attrCond));
			Assert::IsFalse(test.testRegex("with ab.procName = \"first\" and", attrCond));

			Assert::IsTrue(test.testRegex("such that Follows* ( _,_)", suchThat));
			Assert::IsTrue(test.testRegex("such that Parent(12,90)", suchThat));
			Assert::IsTrue(test.testRegex("such that Follows (Z1,a129#)", suchThat));
			Assert::IsFalse(test.testRegex("such that Parent *(0ab,90)", suchThat));
			Assert::IsFalse(test.testRegex("such that Parent * (#b,abc)", suchThat));

			Assert::IsTrue(test.testRegex("such that Uses (_,_)", suchThat));
			Assert::IsTrue(test.testRegex("such that Uses(ab1,ab2)", suchThat));
			Assert::IsTrue(test.testRegex("such that Uses (\"a\",_)", suchThat));
			Assert::IsFalse(test.testRegex("such that Uses (\"1a\",_)", suchThat));
			Assert::IsTrue(test.testRegex("such that Uses (123,_)", suchThat));
			Assert::IsFalse(test.testRegex("such that Uses (\"#a2\",_)", suchThat));
			Assert::IsTrue(test.testRegex("such that Modifies (_,a12#)", suchThat));
			Assert::IsFalse(test.testRegex("such that Modifies (_,#2)", suchThat));
			Assert::IsFalse(test.testRegex("such that Modifies (_,12)", suchThat));
			Assert::IsFalse(test.testRegex("such that Modifies (_,\"#2\")", suchThat));
			Assert::IsTrue(test.testRegex("such that Modifies (_,\"a1\")", suchThat));

			Assert::IsTrue(test.testRegex("such that Calls (_,_)", suchThat));
			Assert::IsTrue(test.testRegex("such that Calls (1,2)", suchThat));
			Assert::IsTrue(test.testRegex("such that Calls (ab3,\"second\")", suchThat));
			Assert::IsTrue(test.testRegex("such that Calls*( _ , \"second\" )", suchThat));
			Assert::IsFalse(test.testRegex("such that Call (_,\"second\")", suchThat));
			Assert::IsFalse(test.testRegex("such that Calls (_,_,\"second\")", suchThat));
			Assert::IsFalse(test.testRegex("such that Calls** (_,\"second\")", suchThat));

			Assert::IsTrue(test.testRegex("such that Next( _ , _ )", suchThat));
			Assert::IsTrue(test.testRegex("such that Next*( _ , _ )", suchThat));
			Assert::IsTrue(test.testRegex("such that Next*( 1 , 22 )", suchThat));
			Assert::IsTrue(test.testRegex("such that Next*( a3 , 22 )", suchThat));
			Assert::IsFalse(test.testRegex("such that Next( 1 , \"hello\" )", suchThat));
			Assert::IsFalse(test.testRegex("such that Next(\"lo\",22 )", suchThat));

			Assert::IsTrue(test.testRegex("such that Next(_,_) and Calls(_,_) and Uses (_,_)", suchThat));
			Assert::IsTrue(test.testRegex("such that Next(_,_) and Parent(12,90)", suchThat));
			Assert::IsFalse(test.testRegex("such that Next(_,_) and", suchThat));
			Assert::IsFalse(test.testRegex("such that Next(_,_) Parent(1,2)", suchThat));

			Assert::IsTrue(test.testRegex("pattern a(_,_,_)", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",_,_)", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(12,_,_)", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",_)", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(\"x\",_,)", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(\"x\",a)", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",\"a\")", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",_\"a\"_)", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(\"x\",_\"a\")", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(\"x\",\"a\"_)", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",\"a+1*c\")", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",\" a + 1 * c \")", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",\"a-b*c\")", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(\"x\",\"-a+c\")", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(\"x\",\"c*m+\")", patternCond));
			Assert::IsFalse(test.testRegex("pattern a(\"x\",\"c**m\")", patternCond));
			Assert::IsTrue(test.testRegex("pattern a(\"x\",\"c*m*2a\")", patternCond));
			Assert::IsTrue(test.testRegex("pattern i(\"x\", _ , _ )", patternCond));
			Assert::IsTrue(test.testRegex("pattern i(\"x\",_,_)", patternCond));
			Assert::IsTrue(test.testRegex("pattern w(\"x\",_)", patternCond));
			Assert::IsFalse(test.testRegex("pattern i(\"x\",_,_,_)", patternCond));
			Assert::IsFalse(test.testRegex("pattern i(\"x\",_,\"a\")", patternCond));

			Assert::IsTrue(test.testRegex("pattern i(\"x\",_,_) and a(\"x\",\"a+1*c\")", patternCond));
			Assert::IsTrue(test.testRegex("pattern i(\"x\",_,_) and a(_,_,_) and w(\"x\",_)", patternCond));
			Assert::IsFalse(test.testRegex("pattern i(\"x\",_,_) a(_,_,_) and w(\"x\",_)", patternCond));
			Assert::IsFalse(test.testRegex("pattern i(\"x\",_,_) and", patternCond));

		}

		TEST_METHOD(TestParseQuery)
		{
			// TODO: Your test code here
			QueryParser test1;
			//Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a such that Uses(a,v) pattern a(v,_)"));
			Assert::IsTrue(test1.parseQuery("assign a,a1; variable v; Select a such that Uses(a,v) pattern a1(_,_)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a,b,c such that Uses(a,v)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a patterna1(v,_)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select 1a"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a suchthat Uses(a,v)"));

			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a such that Uses(a,v) and Parent(1,2) and Next(_,_) and a1(_,_)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a such that Uses(a,v) and Parent(1,2) and Next(_,_) pattern a1(_,_) and Next(1,2)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a and Next(_,_)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a and a1(_,_)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a such that Calls(_,_) and pattern a(_,_)"));
			Assert::IsFalse(test1.parseQuery("assign a,a1; variable v; Select a such that Calls(_,_) and a(_,_)"));
			Assert::IsTrue(test1.parseQuery("assign a,a1; variable v; Select a pattern a1(_,_) and a(_,\"ss\") such that Uses(a,v)"));
			Assert::IsTrue(test1.parseQuery("assign a,a1; variable v; Select a pattern a1(_,_) such that Uses(a,v) and Parent(_,2) such that Affects(3,_) and Affects(_,3) pattern a(_,_) and a1(v,\"x\")"));
			
			Assert::IsTrue(test1.parseQuery("assign a,a1; variable v; constant c1; stmt st1; prog_line pl; Select a such that Follows(a,_) with st1 .stmt#= c1. value and a1 . stmt# =10 and a  .stmt# = pl"));

		}

		TEST_METHOD(TestDeclarationParsing)
		{
			// TODO: Your test code here
			QueryParser test;
			Assert::IsTrue(test.DeclarationParsing(" assign a,b"));
			Assert::IsTrue(test.DeclarationParsing("procedure p"));
			Assert::IsTrue(test.DeclarationParsing("assign a123"));
			Assert::IsTrue(test.DeclarationParsing("assign a1,a2"));
			Assert::IsFalse(test.DeclarationParsing("assign #a4 , a5,a6"));
			Assert::IsFalse(test.DeclarationParsing("call"));
			Assert::IsFalse(test.DeclarationParsing("assign a1,"));
			Assert::IsFalse(test.DeclarationParsing("assign ,a1"));
			Assert::IsFalse(test.DeclarationParsing("assign a1,    a2"));
			Assert::IsFalse(test.DeclarationParsing("assign call c"));

		}

		TEST_METHOD(TestSelectParsing)
		{
			QueryParser test;
			test.DeclarationParsing("assign a,b,c,d");
			test.DeclarationParsing("procedure p1");
			test.DeclarationParsing("constant c1");
			test.DeclarationParsing("variable v");

			Assert::IsTrue(test.SelectParsing(" Select BOOLEAN"));

			Assert::IsTrue(test.SelectParsing("Select a"));
			Assert::IsFalse(test.SelectParsing("Select a123"));

			Assert::IsFalse(test.SelectParsing("Select a.value"));
			Assert::IsFalse(test.SelectParsing("Select c1.val"));
			Assert::IsFalse(test.SelectParsing("Select p1.varName"));
			Assert::IsTrue(test.SelectParsing("Select a.stmt#"));
			Assert::IsTrue(test.SelectParsing("Select p1.procName"));
			Assert::IsTrue(test.SelectParsing("Select c1.value"));
			Assert::IsTrue(test.SelectParsing("Select v.varName"));

			Assert::IsTrue(test.SelectParsing("Select <a, d>"));
			Assert::IsFalse(test.SelectParsing("Select < 1a,d>"));
			Assert::IsFalse(test.SelectParsing("Select < a,d, e>"));
			Assert::IsTrue(test.SelectParsing("Select <a,b,c>"));
			Assert::IsFalse(test.SelectParsing("Select <#d,a>"));
			Assert::IsFalse(test.SelectParsing("Select <d>"));

			Assert::IsTrue(test.SelectParsing("Select <a.stmt#, d>"));
			Assert::IsTrue(test.SelectParsing("Select <a.stmt#, p1.procName,v.varName,c1.value>"));
			Assert::IsTrue(test.SelectParsing("Select <a.stmt#, p1,v,c1.value>"));
			Assert::IsTrue(test.SelectParsing("Select <a.stmt#, p1,v.varName,c1>"));
			Assert::IsTrue(test.SelectParsing("Select <a, p1,v.varName,c1.value>"));
			Assert::IsFalse(test.SelectParsing("Select <a.stmt#, d.value, c1.value>"));
			Assert::IsFalse(test.SelectParsing("Select <a, d.stmt#, c1.val>"));
			Assert::IsFalse(test.SelectParsing("Select <a, d.stmt#, c1.value, p1.varName>"));
			Assert::IsFalse(test.SelectParsing("Select <a.stmt#, d., c1.value, p1.varName>"));
			Assert::IsFalse(test.SelectParsing("Select <p1.procName>"));
	

			

		}

		TEST_METHOD(TestRelationshipParsing)
		{
			QueryParser test;
			test.DeclarationParsing("assign a1,ab");
			test.DeclarationParsing("variable v");
			test.DeclarationParsing("stmt s1");
			test.DeclarationParsing("while w");
			test.DeclarationParsing("constant c");
			test.DeclarationParsing("prog_line pl");

			Assert::IsTrue(test.RelationshipParsing("Parent*( 12 , a1 )"));
			Assert::IsTrue(test.RelationshipParsing("Uses( \"x1\" , v )"));
			Assert::IsTrue(test.RelationshipParsing("Uses( \"xb\" , \"xa\")"));
			Assert::IsFalse(test.RelationshipParsing("Follows ( a , _)"));
			Assert::IsFalse(test.RelationshipParsing("Follows( a1 , a)"));
			Assert::IsFalse(test.RelationshipParsing("Modifies( _ , v)"));
			Assert::IsFalse(test.RelationshipParsing("Modifies( b , c)"));
			Assert::IsTrue(test.RelationshipParsing("Uses(a1,v)"));
			Assert::IsFalse(test.RelationshipParsing("Parent(w,v)"));
			Assert::IsTrue(test.RelationshipParsing("Parent(w,s1)"));
			Assert::IsTrue(test.RelationshipParsing("Parent(pl,s1)"));
			Assert::IsFalse(test.RelationshipParsing("Parent(v,s1)"));
			Assert::IsTrue(test.RelationshipParsing("Uses(w,v)"));
			Assert::IsFalse(test.RelationshipParsing("Uses(w,a)"));

		}

		TEST_METHOD(TestPatternParsing)
		{
			QueryParser test;
			test.DeclarationParsing("assign a");
			test.DeclarationParsing("if i");
			test.DeclarationParsing("while w");
			test.DeclarationParsing("variable abc");

			Assert::IsTrue(test.PatternParsing("a(abc,\"x+10\")"));
			Assert::IsTrue(test.PatternParsing("a(abc,_\"x*10-z\"_)"));
			Assert::IsFalse(test.PatternParsing("q(abc,_\"x*10-z\"_)"));
			Assert::IsFalse(test.PatternParsing("a(ab,_\"x*10-z\"_)"));
			Assert::IsTrue(test.PatternParsing("a(_,_\"x*10-z\"_)"));
			Assert::IsTrue(test.PatternParsing("a(\"ab\",_\"x*10-z\"_)"));
			Assert::IsTrue(test.PatternParsing("a(\"ab\",_)"));

			Assert::IsTrue(test.PatternParsing("i(_,_,_)"));
			Assert::IsTrue(test.PatternParsing("i(abc,_ , _)"));
			Assert::IsFalse(test.PatternParsing("i(\"abc\",\"x+10\",_)"));
			Assert::IsFalse(test.PatternParsing("i(abc,_,\"abc\")"));

			Assert::IsTrue(test.PatternParsing("w(_,_)"));
			Assert::IsFalse(test.PatternParsing("w(abc,_\"x*10-z\"_)"));
			Assert::IsFalse(test.PatternParsing("w(\"abc\",\"x+10\")"));

			Assert::IsFalse(test.PatternParsing("abc(_,\"x+10\")"));

		}

		TEST_METHOD(TestWithParsing) 
		{
			QueryParser test;
			test.DeclarationParsing("procedure p1");
			test.DeclarationParsing("stmt st1");
			test.DeclarationParsing("assign a1");
			test.DeclarationParsing("call ca1");
			test.DeclarationParsing("while w1");
			test.DeclarationParsing("if i1");
			test.DeclarationParsing("variable v1");
			test.DeclarationParsing("constant c1");
			test.DeclarationParsing("prog_line pl1, pl2");

			Assert::IsTrue(test.AttributeParsing("a1.stmt#= c1.value"));
			Assert::IsTrue(test.AttributeParsing("a1.stmt# =pl1"));
			Assert::IsFalse(test.AttributeParsing("a1.stmt# = \"asd\""));
			Assert::IsTrue(test.AttributeParsing("a1.stmt#=12"));
			Assert::IsFalse(test.AttributeParsing("a1.value = 2"));
			Assert::IsFalse(test.AttributeParsing("a1.varName = \"asd\""));
			Assert::IsFalse(test.AttributeParsing("a1.procName = \"asd\""));

			Assert::IsFalse(test.AttributeParsing("p1.procName = c1.value"));
			Assert::IsFalse(test.AttributeParsing("p1.procName = pl1"));
			Assert::IsTrue(test.AttributeParsing("p1.procName = \"asd\""));
			Assert::IsFalse(test.AttributeParsing("p1.procName = 12"));
			Assert::IsFalse(test.AttributeParsing("p1.value = 2"));
			Assert::IsFalse(test.AttributeParsing("p1.varName = \"asd\""));
			Assert::IsFalse(test.AttributeParsing("p1.stmt# = \"asd\""));

			Assert::IsFalse(test.AttributeParsing("v1.varName = c1.value"));
			Assert::IsFalse(test.AttributeParsing("v1.varName = pl1"));
			Assert::IsTrue(test.AttributeParsing("v1.varName = \"asd\""));
			Assert::IsFalse(test.AttributeParsing("v1.varName = 12"));
			Assert::IsFalse(test.AttributeParsing("v1.value = 2"));
			Assert::IsFalse(test.AttributeParsing("v1.procName = \"asd\""));
			Assert::IsFalse(test.AttributeParsing("v1.stmt# = \"asd\""));

			Assert::IsTrue(test.AttributeParsing("c1.value = c1.value"));
			Assert::IsTrue(test.AttributeParsing("c1.value = pl1"));
			Assert::IsFalse(test.AttributeParsing("c1.value = \"asd\""));
			Assert::IsTrue(test.AttributeParsing("c1.value = 12"));
			Assert::IsFalse(test.AttributeParsing("c1.varName = \"aa\""));
			Assert::IsFalse(test.AttributeParsing("c1.procName = \"asd\""));
			Assert::IsFalse(test.AttributeParsing("c1.stmt# = 31"));

			Assert::IsTrue(test.AttributeParsing("pl1 = 12"));
			Assert::IsFalse(test.AttributeParsing("pl1 = \"asd\""));
			Assert::IsTrue(test.AttributeParsing("pl1 = pl2"));
			Assert::IsFalse(test.AttributeParsing("v1 = \"asd\""));

			Assert::IsTrue(test.AttributeParsing("\"first\" = \"second\""));
			Assert::IsFalse(test.AttributeParsing("\"first\" = 12"));

			Assert::IsTrue(test.AttributeParsing("13 = 12"));
			Assert::IsFalse(test.AttributeParsing("13 = \"second\""));

			Assert::IsTrue(test.AttributeParsing("13 = st1.stmt#"));
			Assert::IsFalse(test.AttributeParsing("\"qwe\" = st1.stmt#"));
			Assert::IsTrue(test.AttributeParsing("3 = pl1"));
			Assert::IsTrue(test.AttributeParsing("pl1 = w1.stmt#"));

		}
	};
}