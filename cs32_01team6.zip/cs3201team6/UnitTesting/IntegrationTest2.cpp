#include "stdafx.h"
#include "CppUnitTest.h"
#include "FileParser.h"
#include "QueryParser.h"
#include "ProgramKnowledgeBase.h"
#include <sstream>

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace IntegretionTest2
{
	TEST_CLASS(UnitTest1)
	{
	private:
		QueryParser qp;

		inline std::string resToStr(std::list<std::string> res) {
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			switch (res.size())
			{
			case 0:
				return std::string();
			case 1:
				return res.front();
			default:
				std::stringstream oss;
				std::for_each(res.begin(), --res.end(), [&oss](std::string str) {
					oss << str << ", ";
				});
				oss << res.back();
				return oss.str();
			}

		}
	public:
		TEST_CLASS_INITIALIZE(init) {
			auto& pkb = ProgramKnowledgeBase::getInstance();
			pkb.clean();
			//assume parser and pkb are tested
			FileParser("../tests/SIMPLE1.txt").parse();
		}
		
		TEST_METHOD(Inte5)
		{
			qp.parseQuery("assign a; Select a such that Next(_,a)");
			auto res = qp.queryResult();
			std::string expected = "4, 6, 8, 9, 10, 12, 13, 16, 17, 19, 21, 23, 24, 25, 26, 29, 31, 32, 33, 34, 36, 38, 39";
			Assert::AreEqual(expected, resToStr(res), false);
		}
		TEST_METHOD(Inte6)
		{
			auto& pkb = ProgramKnowledgeBase::getInstance();
			pkb.clean();
			//assume parser and pkb are tested
			FileParser("../tests/Source9-CALLS.txt").parse();
		}
	};
}