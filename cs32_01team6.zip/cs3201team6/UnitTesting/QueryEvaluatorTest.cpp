#include "stdafx.h"
#include "CppUnitTest.h"
//#include "QueryEvaluator.h"
#include "QueryEvaluator.h"
#include "ProgramKnowledgeBase.h"

//for debug
#include "FileParser.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace QueryEvaluatorTest
{
	TEST_CLASS(UnitTest1)
	{
	private:
		//utility functions
		//type, arg1, arg1type, ar2, arg2type
		Clause genCla(const std::tuple<ClauseType, std::string, ArgType, std::string, ArgType, bool>& input, std::string ptnStr = std::string(), bool us = false) {
			Clause res;
			res.type = std::get<0>(input);
			res.asterisk = std::get<5>(input);

			Synonym l;
			l.name = std::get<1>(input);
			l.type = std::get<2>(input);
			Synonym r;
			r.name = std::get<3>(input);
			r.type = std::get<4>(input);
			if (ptnStr.empty()) {
				res.arg1 = l;
				res.arg2 = r;
			} else {
				res.patternSyn = l;
				res.arg1 = r;
				Synonym p;
				p.type = ArgType::NIL;
				p.name = ptnStr;
				res.arg2 = p;
				res.patternUnderscore = us;
			}
			
			return res;
		}

		Synonym genSyn(const std::pair<std::string, ArgType>& input) {
			Synonym r;
			r.name = input.first;
			r.type = input.second;
			return r;
		}
	public:
		TEST_CLASS_INITIALIZE(init) {
			auto& pkb = ProgramKnowledgeBase::getInstance();
			pkb.clean();
			//assume parser and pkb are tested
			FileParser("../Sample.txt").parse();
		}
		TEST_METHOD(TestParentProcess1)
		{
			//"stmt s; Select s such that Parent*(4,s)";
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("s", ArgType::STMT)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::PARENT, "4", ArgType::NIL, "s", ArgType::STMT, true)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;

			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if(!resstring.empty()) resstring.pop_back();

			std::string expected = "5 6 7 8 9";

			Assert::AreEqual(resstring, expected, false);
			//Assert::IsTrue(res.empty());
		}
		TEST_METHOD(TestParentProcess2)
		{
			//"assign a; while w; Select a such that Parent(w, a) "
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("a", ArgType::ASSIGN)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::PARENT, "w", ArgType::WHILE, "a", ArgType::ASSIGN, false)));
			
			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "5 7 8 9 11 12 13 14 16 18 20 22";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestFollowsProcess1)
		{
			//"stmt s; Select s such that Follows*(5, s)"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("s", ArgType::STMT)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::FOLLOWS, "5", ArgType::NIL, "s", ArgType::STMT, true)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "6 9";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestFollowsProcess2)
		{
			//"stmt s; Select s such that Follows*(s, 9)"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("s", ArgType::STMT)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::FOLLOWS, "s", ArgType::STMT, "9", ArgType::NIL, true)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "5 6";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestUsesProcess1)
		{
			//"stmt s; Select s such that Uses(s, \"z\")"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("s", ArgType::STMT)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::USES, "s", ArgType::STMT, "z", ArgType::NIL, false)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "2 3 4 6 7 9";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestUsesProcess2)
		{
			//"procedure p; Select p such that Uses(p, \"z\")"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("p", ArgType::PROCEDURE)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::USES, "p", ArgType::PROCEDURE, "z", ArgType::NIL, false)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "apple";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestUsesProcess3)
		{
			//"variable v; Select v such that Uses(7, v)"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("v", ArgType::VARIABLE)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::USES, "7", ArgType::NIL, "v", ArgType::VARIABLE, false)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "w x z";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestModifiesProcess1)
		{
			//"stmt s; Select s such that Modifies(s, \"x\")"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("s", ArgType::STMT)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::MODIFIES, "s", ArgType::STMT, "x", ArgType::NIL, false)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "1 4 6 8";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestModifiesProcess2)
		{
			//"procedure p; Select p such that Modifies(p, \"x\")"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("p", ArgType::PROCEDURE)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::MODIFIES, "p", ArgType::PROCEDURE, "x", ArgType::NIL, false)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});
			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "apple";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestModifiesProcess3)
		{
			//"variable v; Select v such that Modifies(4, v)"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("v", ArgType::VARIABLE)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::MODIFIES, "4", ArgType::NIL, "v", ArgType::VARIABLE, false)));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "t x y";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestPatternProcess1)
		{
			//"assign a; Select a pattern a(_, _\"x+z\"_)"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("a", ArgType::ASSIGN)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::PATTERN, "a", ArgType::ASSIGN, "v", ArgType::VARIABLE, false), "((x)+z)", true));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "3 7";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestPatternProcess2)
		{
			//"assign a; Select a pattern a(\"x\", _)"
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("a", ArgType::ASSIGN)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::PATTERN, "a", ArgType::ASSIGN, "x", ArgType::NIL, false), "_", false));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
			return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "1 8";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestPatternProcess3)
		{
			//"variable v; assign a; while w; Select w such that Uses(w, v) pattern a (v, _)");
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("w", ArgType::WHILE)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::USES, "w", ArgType::WHILE, "v", ArgType::VARIABLE, false)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::PATTERN, "a", ArgType::ASSIGN, "v", ArgType::VARIABLE, false), "_", false));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "4 6 10 15 17 19 21";
			Assert::AreEqual(resstring, expected, false);
		}
		TEST_METHOD(TestPatternProcess4)
		{
			//"variable v; assign a; while w; Select w such that Uses(w, v) pattern a (v, _)");
			QueryEvaluator evaluator;
			auto selected = std::vector<Synonym>();
			auto clauses = std::vector<Clause>();
			selected.push_back(genSyn(std::make_pair("a", ArgType::ASSIGN)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::USES, "a", ArgType::ASSIGN, "v", ArgType::VARIABLE, false)));
			clauses.push_back(genCla(std::make_tuple(ClauseType::PATTERN, "a", ArgType::ASSIGN, "v", ArgType::VARIABLE, false), "_", false));

			auto res = evaluator.process(selected, clauses);
			res.sort([](const std::string& l, const std::string& r) {
				return l.length() == r.length() ? l < r : l.length() < r.length();
			});

			std::string resstring;
			for (auto str : res)
			{
				resstring.append(str);
				resstring.append(" ");
			}
			if (!resstring.empty()) resstring.pop_back();
			std::string expected = "1 2";
			Assert::AreEqual(resstring, expected, false);
		}
	};
}