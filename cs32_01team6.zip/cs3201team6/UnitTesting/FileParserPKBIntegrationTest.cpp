#include "stdafx.h"
#include "CppUnitTest.h"
#include "ProgramKnowledgeBase.h"
#include "Procedure.h"
#include "Statement.h"
#include "stmt_type.h"
#include "FileParser.h"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace FileParserPKBIntegrationTest
{
	TEST_CLASS(UnitTest1)
	{
	public:
		ProgramKnowledgeBase& pkb = ProgramKnowledgeBase::getInstance();
		TEST_METHOD(InteTestParse)
		{
			FileParser("../Sample.txt").parse();
		}
		TEST_METHOD(InteTestFollow)
		{
			Assert::IsTrue(pkb.isFollow(1, 2), false);
		}
		TEST_METHOD(InteTestFollows)
		{
			Assert::IsTrue(pkb.isFollowS(1, 3), false);
		}
		TEST_METHOD(InteTestParent)
		{
			Assert::IsTrue(pkb.isParent(4, 5), false);
			Assert::IsFalse(pkb.isParent(3, 5), false);
		}
		TEST_METHOD(InteTestParents)
		{
			Assert::IsTrue(pkb.isParentS(4, 7), false);
			Assert::IsTrue(pkb.isParentS(6, 8), false);
			Assert::IsFalse(pkb.isParentS(3, 7), false);
		}
		TEST_METHOD(InteTestProcUse1)
		{
			bool res = pkb.isUsesP("apple", "x");
			Assert::IsTrue(res, false);
		}
		TEST_METHOD(InteTestProcUse2)
		{
			bool res = pkb.isUsesP("apple", "t");
			Assert::IsFalse(res, false);
		}
		TEST_METHOD(InteTestStmtUse1)
		{
			bool res = pkb.isUsesS(1, "x");
			Assert::IsTrue(res, false);
		}
		TEST_METHOD(InteTestStmtUse2)
		{
			bool res = pkb.isUsesS(2, "x");
			Assert::IsFalse(res, false);
		}
		TEST_METHOD(InteTestAllVarPUse)
		{
			std::string res = pkb.printStringSet(pkb.allVarUsesP("apple"));
			Assert::AreEqual(res, std::string("w x y z"), false);
		}
		TEST_METHOD(InteTestAllVarSUse1)
		{
			std::string res = pkb.printStringSet(pkb.allVarUsesS(7));
			Assert::AreEqual(res, std::string("w x z"), false);
		}
		TEST_METHOD(InteTestAllVarSUse2)
		{
			std::string res = pkb.printStringSet(pkb.allVarUsesS(4));
			Assert::AreEqual(res, std::string("w x y z"), false);
		}
		TEST_METHOD(InteTestAllStmtVarUse)
		{
			std::string res = pkb.printIntSet(pkb.allStmtUses("z", stmt_type::type_any));
			Assert::AreEqual(res, std::string("2 3 4 6 7 9"), false);
		}
		TEST_METHOD(InteTestProcModify1)
		{
			bool res = pkb.isModifiesP("apple", "x");
			Assert::IsTrue(res, false);
		}
		TEST_METHOD(InteTestProcModify2)
		{
			bool res = pkb.isModifiesP("apple", "w");
			Assert::IsFalse(res, false);
		}
		TEST_METHOD(InteTestStmtModify1)
		{
			bool res = pkb.isModifiesS(1, "x");
			Assert::IsTrue(res, false);
		}
		TEST_METHOD(InteTestStmtModify2)
		{
			bool res = pkb.isModifiesS(1, "y");
			Assert::IsFalse(res, false);
		}
		TEST_METHOD(InteTestAllVarPModify)
		{
			std::string res = pkb.printStringSet(pkb.allVarModifiesP("apple"));
			Assert::AreEqual(res, std::string("t x y z"), false);
		}
		TEST_METHOD(InteTestAllVarSModify1)
		{
			std::string res = pkb.printStringSet(pkb.allVarModifiesS(7));
			Assert::AreEqual(res, std::string("t"), false);
		}
		TEST_METHOD(InteTestAllVarSModify2)
		{
			std::string res = pkb.printStringSet(pkb.allVarModifiesS(4));
			Assert::AreEqual(res, std::string("t x y"), false);
		}
		TEST_METHOD(InteTestAllStmtVarModify)
		{
			std::string res = pkb.printIntSet(pkb.allStmtModifies("t", stmt_type::type_any));
			Assert::AreEqual(res, std::string("4 5 6 7"), false);
		}
		TEST_METHOD(InteTestRightBracket)
		{
			Assert::IsTrue(pkb.isParent(4, 9), false);
			Assert::IsFalse(pkb.isParent(6, 9), false);
			Assert::IsFalse(pkb.isModifiesS(6, "y"));
			Assert::IsTrue(pkb.isModifiesS(4, "y"));
		}
		TEST_METHOD(InteTestFilterByPattern3)
		{
			std::set<unsigned int> set = pkb.getAllWhile();
			pkb.filterByPattern(set, std::string("x"), std::string("_"), false);
			std::string res = pkb.printIntSet(set);
			Assert::AreEqual(res, std::string("4 10 15 17 19 21"), false);
		}
		TEST_METHOD(InteTestNext)
		{
			Assert::IsTrue(pkb.isNext(1, 2), false);
			Assert::IsFalse(pkb.isNext(1, 3), false);
			Assert::IsTrue(pkb.isNext(3, 4), false);
			Assert::IsTrue(pkb.isNext(6, 9), false);
			Assert::IsTrue(pkb.isNext(8, 6), false);
			Assert::IsTrue(pkb.isNext(9, 4), false);
		}
		TEST_METHOD(InteTestNextS)
		{
			Assert::IsTrue(pkb.isNextS(1, 2), false);
			Assert::IsTrue(pkb.isNextS(1, 3), false);
			Assert::IsTrue(pkb.isNextS(3, 4), false);
			Assert::IsTrue(pkb.isNextS(5, 4), false);
			Assert::IsTrue(pkb.isNextS(5, 5), false);
			Assert::IsTrue(pkb.isNextS(8, 5), false);
			Assert::IsFalse(pkb.isNextS(3, 1), false);
			Assert::IsFalse(pkb.isNextS(8, 3), false);
		}
		TEST_METHOD(InteTestAffect)
		{
			Assert::IsTrue(pkb.isAffect(1, 3), false);
			Assert::IsTrue(pkb.isAffect(3, 5), false);
			Assert::IsTrue(pkb.isAffect(8, 5), false);
			Assert::IsTrue(pkb.isAffect(8, 7), false);
			Assert::IsFalse(pkb.isAffect(1, 2), false);
		}
		TEST_METHOD(InteTestAffectS)
		{
			Assert::IsTrue(pkb.isAffectS(14, 11), false);
			Assert::IsTrue(pkb.isAffectS(22, 16), false);
		}
	};
}