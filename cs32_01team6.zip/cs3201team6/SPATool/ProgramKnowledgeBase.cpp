#include "ProgramKnowledgeBase.h"
#include "Procedure.h"
#include "Statement.h"
#include <stack>
#include <map>
#include <iostream>

ProgramKnowledgeBase & ProgramKnowledgeBase::getInstance()
{
	static ProgramKnowledgeBase myInstance;
	return myInstance;
}

ProgramKnowledgeBase::~ProgramKnowledgeBase()
{
}

void ProgramKnowledgeBase::clean()
{
	current_line = 1;
	current_procedure = nullptr;
	procs.clear();
	assigns.clear();
	ifstmts.clear();
	whiles.clear();
	stmts.clear();
	stmtLsts.clear();
	vars.clear();
	constants.clear();
	calls.clear();

	for (auto item : procIndex) {
		delete item.second;
	}
	procIndex.clear();
	for (auto item : varTable) {
		delete item.second;
	}
	varTable.clear();
	stmtTable.clear();
}

void ProgramKnowledgeBase::addProcedure(const std::string & name)
{
	if (procIndex.find(name) == procIndex.end())
	{
		Procedure* proc = new Procedure(name);
		procIndex.insert(std::make_pair(name, proc));
		current_procedure = proc;
		procs.insert(name);
	}
	else
	{
		current_procedure = procIndex.at(name);
	}
	stmtLsts.insert(current_line);
}


void ProgramKnowledgeBase::addAssign(const std::string& var, const std::set<std::string>& expvars, const std::string& expression, const std::set<unsigned int>& consts)
{	
	constants.insert(consts.begin(), consts.end());
	varTable.insert(std::make_pair(var, new Variable(var)));
	vars.insert(var);
	vars.insert(expvars.begin(), expvars.end());
	Assign* assign = new Assign(current_line, varTable.at(var), expression);
	addNode(assign);
	associateStmtAndVarModifies(assign, var);
	for (std::set<std::string>::iterator it = expvars.begin(); it != expvars.end(); ++it)
	{
		varTable.insert(std::make_pair(*it, new Variable(*it)));
		associateStmtAndVarUses(assign, *it);
	}
	assigns.insert(assign->line_number);
	stmts.insert(assign->line_number);
}

void ProgramKnowledgeBase::addCall(const std::string& callee)
{
	Procedure* proc;
	bool exist = false;
	if (procIndex.find(callee) == procIndex.end())
	{
		proc = new Procedure(callee);
		procIndex.insert(std::make_pair(callee, proc));
		procs.insert(callee);
	}
	else
	{
		proc = procIndex.at(callee);
		exist = true;
	}

	Call* call = new Call(current_line, proc);
	addNode(call);
	stmts.insert(call->line_number);

	if (proc == current_procedure) throw std::exception("recursvie call"); //forbid recursvie call
	for (auto i = current_procedure->callerStack.begin(); i != current_procedure->callerStack.end(); ++i)
	{
		if (proc == *i) throw std::exception("recursvie call"); //forbid recursive call
		proc->addCaller(*i);
		(*i)->addCallee(proc);
	}
	for (auto i = current_procedure->callerStmts.begin(); i != current_procedure->callerStmts.end(); ++i)
	{
		proc->addCallerStmt(*i);
	}
	proc->addCaller(current_procedure);
	proc->addCallerStmt(call);
	proc->addDirectCaller(current_procedure);
	current_procedure->addCallee(proc);
	current_procedure->addDirectCallee(proc);
	calls.insert(call->line_number);
	stmts.insert(call->line_number);
	if (exist)
	{
		for (auto i = proc->modifiedVars.begin(); i != proc->modifiedVars.end(); ++i)
		{
			call->addToModify(*i);
		}
		for (auto i = proc->usedVars.begin(); i != proc->usedVars.end(); ++i)
		{
			call->addToUse(*i);
		}
	}	
}

void ProgramKnowledgeBase::addWhile(const std::string& control_var)
{
	varTable.insert(std::make_pair(control_var, new Variable(control_var)));
	vars.insert(control_var);
	While* w = new While(current_line, varTable.at(control_var));
	addNode(w);
	associateStmtAndVarUses(w, control_var);
	current_procedure->current_container = w;
	current_procedure->parentStack.push_back(w);
	whiles.insert(w->line_number);
	stmts.insert(w->line_number);
	stmtLsts.insert(current_line);
}

void ProgramKnowledgeBase::addIf(const std::string& control_var)
{
	varTable.insert(std::make_pair(control_var, new Variable(control_var)));
	vars.insert(control_var);
	If* ifs = new If(current_line, varTable.at(control_var));
	addNode(ifs);
	associateStmtAndVarUses(ifs, control_var);
	current_procedure->current_container = ifs;
	current_procedure->parentStack.push_back(ifs);
	ifstmts.insert(ifs->line_number);
	stmts.insert(ifs->line_number);
	stmtLsts.insert(current_line);
}

void ProgramKnowledgeBase::beginElse()
{
	auto container = current_procedure->current_container;
	container->isNextChildInElse = true;
	container->firstElseChildIndex = container->childList.size();
	stmtLsts.insert(current_line);
}

void ProgramKnowledgeBase::rightBracket()
{
	if (!current_procedure->parentStack.empty())
	{
		Statement* container = current_procedure->parentStack.back();
		if (container->type == stmt_type::type_if && container->isNextChildInElse == false) {
			return;
		}

		if (container->type == stmt_type::type_while)
		{
			Statement* laststmt = container->childList.back();
			if (container->childList.back()->type != stmt_type::type_if)
			{
				if (container->childList.back()->next[0] == NULL)
				{
					container->childList.back()->next[0] = container;
				}
				else
				{
					container->childList.back()->next[1] = container; //this is while{...while{}} case
				}
				container->prev.push_back(container->childList.back());
			}
			else
			{
				Statement::addNextToIfRightSibling(container->childList.back(), container);
			}
		}

		current_procedure->parentStack.pop_back();

		if (!current_procedure->parentStack.empty())
		{
			current_procedure->current_container = current_procedure->parentStack.back();
		}
		else
		{
			current_procedure->current_container = nullptr;
		}
	}
}

void ProgramKnowledgeBase::associateStmtAndVarUses(Statement * stmt, std::string var)
{
	stmt->addToUse(varTable.at(var));
	stmt->root_procedure->addToUse(varTable.at(var));
}

void ProgramKnowledgeBase::associateStmtAndVarModifies(Statement * stmt, std::string var)
{
	stmt->addToModify(varTable.at(var));
	stmt->root_procedure->addToModify(varTable.at(var));
}

const std::set<std::string>& ProgramKnowledgeBase::getAllProc()
{
	return procs;
}

const std::set<unsigned int>& ProgramKnowledgeBase::getAllCall()
{
	return calls;
}

const std::set<unsigned int>& ProgramKnowledgeBase::getAllAssign()
{
	return assigns;
}

const std::set<unsigned int>& ProgramKnowledgeBase::getAllWhile()
{
	return whiles;
}

const std::set<unsigned int>& ProgramKnowledgeBase::getAllIf()
{
	return ifstmts;
}

const std::set<unsigned int>& ProgramKnowledgeBase::getAllStmt()
{
	return stmts;
}

const std::set<unsigned int>& ProgramKnowledgeBase::getAllStmtLst()
{
	return stmtLsts;
}

const std::set<std::string>& ProgramKnowledgeBase::getAllVar()
{
	return vars;
}

const std::set<unsigned int>& ProgramKnowledgeBase::getAllConstant()
{
	return constants;
}

bool ProgramKnowledgeBase::isFollow(unsigned int pre, unsigned int cur, bool asterisk)
{
	if (pre > stmtTable.size() || cur > stmtTable.size()) {
		return false;
	}
	if (asterisk) {
		return isFollowS(pre, cur);
	}
	pre -= 1;
	cur -= 1;
	return stmtTable[pre]->rightSibling == stmtTable[cur];
}

bool ProgramKnowledgeBase::isFollowS(unsigned int pre, unsigned int cur)
{
	pre -= 1;
	cur -= 1;
	auto preStmt = stmtTable[pre];
	auto curStmt = stmtTable[cur];
	if (preStmt->root_procedure != curStmt->root_procedure) 
	{
		return false;
	}
	if (preStmt->parent == curStmt->parent && cur > pre)
	{
		if (preStmt->parent != nullptr && preStmt->parent->type == stmt_type::type_if)
		{
			return (preStmt->isSelfInElse == curStmt->isSelfInElse);
		}
		return true;
	}
	return false;
}

bool ProgramKnowledgeBase::isParent(unsigned int parent, unsigned int child, bool asterisk)
{
	if (parent > stmtTable.size() || child > stmtTable.size()) {
		return false;
	}
	if (asterisk) {
		return isParentS(parent, child);
	}
	parent -= 1;
	child -= 1;
	return stmtTable[child]->parent == stmtTable[parent];
}

bool ProgramKnowledgeBase::isParentS(unsigned int parent, unsigned int child)
{
	parent -= 1;
	child -= 1;
	std::vector<Statement*>& ancestors = stmtTable[child]->ancestors;
	return std::find(ancestors.begin(), ancestors.end(), stmtTable[parent]) != ancestors.end();
}

bool ProgramKnowledgeBase::isUsesP(const std::string& proc, const std::string& var)
{
	return procIndex.at(proc)->ifUse(varTable.at(var));
}

bool ProgramKnowledgeBase::isModifiesP(const std::string& proc, const std::string& var)
{
	return procIndex.at(proc)->ifModify(varTable.at(var));
}

bool ProgramKnowledgeBase::isUsesS(unsigned int stmt, const std::string& var)
{
	return stmtTable[stmt-1]->ifUse(varTable.at(var));
}

bool ProgramKnowledgeBase::isModifiesS(unsigned int stmt, const std::string& var)
{
	return stmtTable[stmt-1]->ifModify(varTable.at(var));
}

bool ProgramKnowledgeBase::isNext(unsigned int pre, unsigned int cur, bool asterisk)
{
	if (pre > stmtTable.size() || cur > stmtTable.size() || stmtTable[pre-1]->root_procedure != stmtTable[cur-1]->root_procedure) {
		return false;
	}
	if (asterisk)
	{
		return isNextS(pre, cur);
	}
	pre -= 1;
	cur -= 1;
	return stmtTable[pre]->next[0] == stmtTable[cur] || stmtTable[pre]->next[1] == stmtTable[cur];
}

bool ProgramKnowledgeBase::isNextS(unsigned int pre, unsigned int cur)
{
	pre -= 1;
	cur -= 1;
	Statement* prestmt = stmtTable[pre];
	Statement* curstmt = stmtTable[cur];
	int presize = prestmt->ancestors.size();
	int cursize = curstmt->ancestors.size();
	int minsize = presize < cursize ? presize : cursize;
	int lastsameindex = minsize - 1;

	for (int i = 0; i < minsize; i++)
	{
		if (prestmt->ancestors[i] != curstmt->ancestors[i])
		{
			lastsameindex = i - 1;
			break;
		}
		if (prestmt->ancestors[i]->type == stmt_type::type_while) //if belong to a common while parent, return true
		{
			return true;
		}
	}
	if (curstmt->type == stmt_type::type_while && cursize < presize && prestmt->ancestors[minsize] == curstmt)
	{	//cur is while parent of pre
		return true;
	}
	if (pre > cur)
	{
		return false;
	}
	else if (pre == cur)
	{   //identical while stmt
		if (prestmt->type == stmt_type::type_while) return true;
		else return false;
	}
	else
	{
		if (lastsameindex >= 0 && prestmt->ancestors[lastsameindex]->type == stmt_type::type_if)
		{   //if belong to different branch of a common if parent, return false
			unsigned int firstElseChildNumber = prestmt->ancestors[lastsameindex]->firstElseChildNumber - 1;
			if ((pre < firstElseChildNumber && cur >= firstElseChildNumber) || (cur < firstElseChildNumber && cur >= firstElseChildNumber))
			{
				return false;
			}
		}
		return true;
	}
}

bool ProgramKnowledgeBase::isAffect(unsigned int pre, unsigned int cur, bool asterisk)
{
	if (stmtTable[pre-1]->type != stmt_type::type_assign || stmtTable[cur-1]->type != stmt_type::type_assign ||
		stmtTable[pre-1]->root_procedure != stmtTable[cur-1]->root_procedure)
	{
		return false;
	}
	if (asterisk)
	{
		return isAffectS(pre, cur);
	}
	pre -= 1;
	cur -= 1;
	if (isNextS(pre+1, cur+1) && std::find(stmtTable[cur]->usedVars.begin(), stmtTable[cur]->usedVars.end(), 
		*(stmtTable[pre]->modifiedVars.begin())) != stmtTable[cur]->usedVars.end())
	{
		std::stack<unsigned int> stack;
		stack.push(pre);
		unsigned int top = -1;
		bool init = false;
		while (!stack.empty())
		{
			top = stack.top(); stack.pop();
			if (init && top == cur) return true; //found!
			if (init && ((stmtTable[top]->type == stmt_type::type_assign &&
				*(stmtTable[pre]->modifiedVars.begin()) == *(stmtTable[top]->modifiedVars.begin())) ||
				stmtTable[top]->type == stmt_type::type_call && stmtTable[top]->modifiedVars.find
				(*(stmtTable[pre]->modifiedVars.begin())) != stmtTable[top]->modifiedVars.end()))
			{
				continue;
			}
			init = true;
			if (stmtTable[top]->next[0] != nullptr)
			{
				if (stmtTable[top]->type == stmt_type::type_while)
				{
					if (isParentS(top + 1, cur + 1))
						stack.push(stmtTable[top]->next[0]->line_number - 1);
					else
					{
						if (stmtTable[top]->next[1] != nullptr)
							stack.push(stmtTable[top]->next[1]->line_number - 1);
					}
				}
				else if (stmtTable[top]->type == stmt_type::type_if && isParentS(top + 1, cur + 1))
				{
					if (cur + 1 >= stmtTable[top]->firstElseChildNumber)
					{
						stack.push(stmtTable[top]->next[1]->line_number - 1);
					}
					else
					{
						stack.push(stmtTable[top]->next[0]->line_number - 1);
					}
				}
				else
				{
					if (stmtTable[top]->next[1] != nullptr)
						stack.push(stmtTable[top]->next[1]->line_number - 1);
					stack.push(stmtTable[top]->next[0]->line_number - 1);
				}
			}			
		}
	}
	
	return false;

}

bool ProgramKnowledgeBase::isAffectS(unsigned int pre, unsigned int cur)
{
	pre -= 1;
	cur -= 1;
	if (isNextS(pre+1, cur+1))
	{
		std::map<unsigned int, std::map<std::string, std::vector<unsigned int>>> whilemap;
		std::map<std::string, std::vector<unsigned int>> mlist;
		std::stack<std::tuple<unsigned int, std::map<std::string, std::vector<unsigned int>>, std::map<unsigned int, std::map<std::string, std::vector<unsigned int>>>>> stack;
		Variable* firstmvar = *(stmtTable[pre]->modifiedVars.begin());
		std::vector<unsigned int> tempvec;
		tempvec.push_back(pre);
		mlist[firstmvar->name] = tempvec;
		stack.push(std::make_tuple(pre, mlist, whilemap));
		unsigned int top = -1;

		while (!stack.empty())
		{
			top = std::get<0>(stack.top()); 
			mlist = std::get<1>(stack.top()); 
			whilemap = std::get<2>(stack.top());
			stack.pop();
			if (top == cur)
			{
				for (auto i = mlist.begin(); i != mlist.end(); ++i)
				{
					if (stmtTable[cur]->usedVars.find(varTable[(*i).first]) != stmtTable[cur]->usedVars.end()
						&& isAffect((*i).second.back()+1, cur+1))
					{
						return true;
					}
				}
			}
			if (stmtTable[top]->type == stmt_type::type_assign)
			{
				for (auto i = mlist.begin(); i != mlist.end(); ++i)
				{
					if (stmtTable[top]->usedVars.find(varTable[(*i).first]) != stmtTable[top]->usedVars.end()
						&& isAffect((*i).second.back() + 1, top + 1))
					{
						Variable* mvar = *(stmtTable[top]->modifiedVars.begin());
						if (mlist.find(mvar->name) == mlist.end())
						{
							std::vector<unsigned int> tempvec;
							tempvec.push_back(top);
							mlist[mvar->name] = tempvec;
						}
						else
						{
							if (std::find(mlist[mvar->name].begin(), mlist[mvar->name].end(), top) == mlist[mvar->name].end())
							{
								mlist[mvar->name].push_back(top);
							}
						}
					}
				}
			}
			if (stmtTable[top]->next[0] != nullptr)
			{
				if (stmtTable[top]->type == stmt_type::type_while)
				{
					if (whilemap.find(stmtTable[top]->line_number-1) != whilemap.end()) //exist in whilemap
					{
						if (whilemap[stmtTable[top]->line_number - 1] == mlist) //unchanged in loop
						{
							if (stmtTable[top]->next[1] != nullptr)
							{
								stack.push(std::make_tuple(stmtTable[top]->next[1]->line_number - 1, mlist, whilemap));
							}
						}
						else //continue looping!
						{
							whilemap[stmtTable[top]->line_number - 1] = mlist; //update
							stack.push(std::make_tuple(stmtTable[top]->next[0]->line_number - 1, mlist, whilemap));
						}
					}
					else
					{
						whilemap[stmtTable[top]->line_number - 1] = mlist;
						stack.push(std::make_tuple(stmtTable[top]->next[0]->line_number - 1, mlist, whilemap)); //go to loop later
						if (stmtTable[top]->next[1] != nullptr)
							stack.push(std::make_tuple(stmtTable[top]->next[1]->line_number - 1, mlist, whilemap));
					}
				}
				else
				{
					if (stmtTable[top]->next[1] != nullptr)
						stack.push(std::make_tuple(stmtTable[top]->next[1]->line_number - 1, mlist, whilemap));
					stack.push(std::make_tuple(stmtTable[top]->next[0]->line_number - 1, mlist, whilemap));
				}
			}
		}
	}

	return false;
}

bool ProgramKnowledgeBase::isCall(const std::string& caller, const std::string& callee, bool asterisk)
{
	if (asterisk) {
		return isCallS(caller, callee);
	}
	if (procIndex.find(callee) == procIndex.end() || procIndex.find(caller) == procIndex.end()) return false;
	return procIndex[callee]->ifDirectCalledBy(procIndex[caller]);
}

bool ProgramKnowledgeBase::isCallS(const std::string& caller, const std::string& callee)
{
	if (procIndex.find(callee) == procIndex.end() || procIndex.find(caller) == procIndex.end()) return false;
	return procIndex[callee]->ifCalledBy(procIndex[caller]);
}

std::set<unsigned int> ProgramKnowledgeBase::allStmtUses(std::string var, stmt_type::stmt_type type)
{
	return varTable.at(var)->getAllUsesStmt(type);
}

std::set<unsigned int> ProgramKnowledgeBase::allStmtModifies(std::string var, stmt_type::stmt_type type)
{
	return varTable.at(var)->getAllModifiesStmt(type);
}

std::set<std::string> ProgramKnowledgeBase::allProcUses(std::string var)
{
	return varTable.at(var)->getAllUsesProc();
}

std::set<std::string> ProgramKnowledgeBase::allProcModifies(std::string var)
{
	return varTable.at(var)->getAllModifiesProc();
}

std::set<std::string> ProgramKnowledgeBase::allVarUsesP(std::string proc)
{
	return procIndex.at(proc)->getAllUsesVar();
}

std::set<std::string> ProgramKnowledgeBase::allVarModifiesP(std::string proc)
{
	return procIndex.at(proc)->getAllModifiesVar();
}

std::set<std::string> ProgramKnowledgeBase::allVarUsesS(unsigned int stmt)
{
	return stmtTable[stmt-1]->getAllUsesVar();
}

std::set<std::string> ProgramKnowledgeBase::allVarModifiesS(unsigned int stmt)
{
	return stmtTable[stmt-1]->getAllModifiesVar();
}

std::set<std::string> ProgramKnowledgeBase::allCallers(std::string proc)
{
	return procIndex[proc]->getAllCallers();
}

std::set<std::string> ProgramKnowledgeBase::allCallees(std::string proc)
{
	return procIndex[proc]->getAllCallees();
}

std::set<std::string> ProgramKnowledgeBase::allDirectCallers(std::string proc)
{
	return procIndex[proc]->getAllDirectCallers();
}

std::set<std::string> ProgramKnowledgeBase::allDirectCallees(std::string proc)
{
	return procIndex[proc]->getAllDirectCallees();
}

std::set<unsigned int> ProgramKnowledgeBase::allNextStmts(unsigned int stmt)
{
	std::set<unsigned int> result;
	if (stmtTable[stmt - 1]->next[0] != NULL) result.insert(stmtTable[stmt - 1]->next[0]->line_number);
	if (stmtTable[stmt - 1]->next[1] != NULL) result.insert(stmtTable[stmt - 1]->next[1]->line_number);
	return result;
}

std::set<unsigned int> ProgramKnowledgeBase::allPrevStmts(unsigned int stmt)
{
	std::set<unsigned int> result;
	for (auto i = stmtTable[stmt - 1]->prev.begin(); i != stmtTable[stmt - 1]->prev.end(); ++i)
	{
		result.insert((*i)->line_number);
	}
	return result;
}

std::set<unsigned int> ProgramKnowledgeBase::allNextSStmts(unsigned int stmt)
{
	stmt -= 1;
	std::set<unsigned int> result;

	std::stack<unsigned int> stack;
	std::set<unsigned int> visited;
	stack.push(stmt);
	unsigned int top = -1;
	bool init = false;
	while (!stack.empty())
	{
		top = stack.top(); stack.pop();
		if (visited.find(top) != visited.end()) continue;
		if (init) visited.insert(top);
		if (init) result.insert(top + 1);
		init = true;
		if (stmtTable[top]->next[0] != nullptr)
		{
			if (stmtTable[top]->next[1] != nullptr)
				stack.push(stmtTable[top]->next[1]->line_number - 1);
			stack.push(stmtTable[top]->next[0]->line_number - 1);
		}
	}
	return result;
}

std::set<unsigned int> ProgramKnowledgeBase::allPrevSStmts(unsigned int stmt)
{
	stmt -= 1;
	std::set<unsigned int> result;

	std::stack<unsigned int> stack;
	std::set<unsigned int> visited;
	stack.push(stmt);
	unsigned int top = -1;
	bool init = false;
	while (!stack.empty())
	{
		top = stack.top(); stack.pop();
		if (visited.find(top) != visited.end()) continue;
		if(init) visited.insert(top);
		if(init) result.insert(top + 1);
		init = true;
		for (auto i = stmtTable[top]->prev.begin(); i != stmtTable[top]->prev.end(); ++i)
		{
			stack.push((*i)->line_number - 1);
		}
	}
	return result;
}

std::set<unsigned int> ProgramKnowledgeBase::allAffectStmts(unsigned int stmt)
{
	std::set<unsigned int> result;
	if (stmtTable[stmt - 1]->type != stmt_type::type_assign)
	{
		return result;
	}
	stmt -= 1;
	std::stack<unsigned int> stack;
	std::set<unsigned int> visited;
	stack.push(stmt);
	unsigned int top = -1;
	bool init = false;
	while (!stack.empty())
	{
		top = stack.top(); stack.pop();
		if (init) visited.insert(top);
		if (init && ((stmtTable[top]->type == stmt_type::type_assign &&
			*(stmtTable[stmt]->modifiedVars.begin()) == *(stmtTable[top]->modifiedVars.begin())) ||
			stmtTable[top]->type == stmt_type::type_call && stmtTable[top]->modifiedVars.find
			(*(stmtTable[stmt]->modifiedVars.begin())) != stmtTable[top]->modifiedVars.end()))
		{
			continue;
		}
		if (init && stmtTable[top]->type == stmt_type::type_assign && 
			std::find(stmtTable[top]->usedVars.begin(), stmtTable[top]->usedVars.end(),
			*(stmtTable[stmt]->modifiedVars.begin())) != stmtTable[top]->usedVars.end())
		{
			result.insert(top + 1);
		}
		init = true;
		if (stmtTable[top]->next[1] != nullptr && visited.find(stmtTable[top]->next[1]->line_number - 1) == visited.end())
			stack.push(stmtTable[top]->next[1]->line_number - 1);
		if (stmtTable[top]->next[0] != nullptr && visited.find(stmtTable[top]->next[0]->line_number - 1) == visited.end())
			stack.push(stmtTable[top]->next[0]->line_number - 1);
	}
	return result;
}

std::set<unsigned int> ProgramKnowledgeBase::allAffectedStmts(unsigned int stmt)
{
	std::set<unsigned int> result;
	if (stmtTable[stmt - 1]->type != stmt_type::type_assign)
	{
		return result;
	}
	stmt -= 1;
	std::stack<std::pair<unsigned int, std::set<std::string>>> stack;
	std::set<unsigned int> visited;
	stack.push(std::make_pair(stmt, std::set<std::string>()));
	unsigned int top = -1;
	bool init = false;
	while (!stack.empty())
	{
		std::set<std::string> modified; //nextS modified in current stack
		top = stack.top().first; modified = stack.top().second; stack.pop();
		if (init) visited.insert(top);
		if (stmtTable[top]->type == stmt_type::type_call)
		{
			for (auto i = stmtTable[top]->modifiedVars.begin(); i != stmtTable[top]->modifiedVars.end(); ++i)
			{
				modified.insert((*i)->name);
			}
		}
		if (init && stmtTable[top]->type == stmt_type::type_assign)
		{
			Variable* modify = *(stmtTable[top]->modifiedVars.begin()); //current modified
			if (stmtTable[stmt]->usedVars.find(modify) != stmtTable[stmt]->usedVars.end() &&
				modified.find(modify->name) == modified.end())
			{
				result.insert(top + 1);
				modified.insert(modify->name);
			}
		}
		init = true;
		for (auto i = stmtTable[top]->prev.begin(); i != stmtTable[top]->prev.end(); ++i)
		{
			if (visited.find((*i)->line_number-1) == visited.end())
				stack.push(std::make_pair((*i)->line_number - 1, modified));
		}
	}
	return result;
}

std::set<unsigned int> ProgramKnowledgeBase::allAffectSStmts(unsigned int stmt)
{
	std::set<unsigned int> result;
	for (auto i = assigns.begin(); i != assigns.end(); ++i)
	{
		if (isAffectS(stmt, (*i))) result.insert(*i);
	}
	return result;
}

std::set<unsigned int> ProgramKnowledgeBase::allAffectedSStmts(unsigned int stmt)
{
	std::set<unsigned int> result;
	for (auto i = assigns.begin(); i != assigns.end(); ++i)
	{
		if (isAffectS((*i), stmt)) result.insert(*i);
	}
	return result;
}

std::string ProgramKnowledgeBase::printStringSet(std::set<std::string>& set)
{
	std::string res;
	for (std::set<std::string>::iterator it = set.begin(); it != set.end(); ++it)
	{
		res += (*it);
		res += " ";
	}
	res.pop_back();
	return res;
}

std::string ProgramKnowledgeBase::printIntSet(std::set<unsigned int>& set)
{
	std::string res;
	for (std::set<unsigned int>::iterator it = set.begin(); it != set.end(); ++it)
	{
		res += std::to_string(*it);
		res += " ";
	}
	if (!res.empty())
	{
		res.pop_back();
	}
	return res;
}


bool ProgramKnowledgeBase::fitPattern(unsigned int line, const std::string& patternStr1, const std::string& patternStr2, bool assignUnderScore)
{
	return stmtTable[line - 1]->fitPattern(patternStr1, patternStr2, assignUnderScore);
}

void ProgramKnowledgeBase::filterByPattern(std::set<unsigned int>& stmtSet, std::string patternStr1, std::string patternStr2, bool assignUnderScore)
{
	for (auto i = stmtSet.begin(); i != stmtSet.end();)
	{
		if (!stmtTable[(*i)-1]->fitPattern(patternStr1, patternStr2, assignUnderScore))
		{
			i = stmtSet.erase(i);
		}
		else
		{
			++i;
		}
	}
}

//## private

ProgramKnowledgeBase::ProgramKnowledgeBase()
{
	current_line = 1;
}

void ProgramKnowledgeBase::addNode(Statement * s)
{
	s->root_procedure = current_procedure;
	s->ancestors = current_procedure->parentStack;
	current_procedure->addChild(s);
	stmtTable.push_back(s);
	current_line++;
}



