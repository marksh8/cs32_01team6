#include "While.h"

While::While(unsigned int line_number, Variable* control_var) : Statement(line_number), control_var(control_var)
{
	type = stmt_type::type_while;
}

While::~While()
{
}

bool While::fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore)
{
	if (patternStr2 != "_") {
		throw std::exception("invalid query");
	}

	return patternStr1 == control_var->name;
}
