#pragma once
#include "Statement.h"

class Assign : public Statement
{
public:
	Assign(unsigned int line_number, Variable* variable, const std::string& expression);
	~Assign();

	const Variable* variable;
	const std::string expression;
	//stores all vars appears after equal sign
	std::set<std::string> useList;

	bool fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore = false);
	//Compress a expression
	std::string compressExpression(const std::string& expr);
private:
	std::string compressExpr(const std::string& expr);
	std::string compressTerm(const std::string& term);
	std::string markerWithInt(int id);
	bool isMarker(std::string& str);
	std::string compressBracket(std::string& expr);
};
