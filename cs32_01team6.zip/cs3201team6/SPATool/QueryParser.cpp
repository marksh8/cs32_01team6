#include "QueryParser.h"
#include <iostream>

QueryParser::QueryParser()
{
	isValidQuery = true;
	errorMsg = "";
	argTypeIndexCount = 1;
}

QueryParser::~QueryParser()
{

}

bool QueryParser::parseQuery(std::string query)
{
	QueryParser::query = query;

	query = trimExcessSpaces(query);
	std::string currentStateOfQuery = trim(query, " \t");

	std::regex decSplit(".+;.+"); //check for ; in the query in order to split into sects

	// Declaration Part
	if (std::regex_match(query, decSplit)) {
		std::string decTemp;
		size_t substrStart = 0;

		size_t tPoint = query.find_first_of(';');
		while (tPoint != std::string::npos) {
			decTemp = query.substr(substrStart, tPoint - substrStart);
			//removing declaration part 1 by 1
			currentStateOfQuery = query.substr(tPoint + 1, query.length());
			DeclarationParsing(decTemp);
			substrStart = tPoint + 1;
			tPoint = query.find_first_of(';', tPoint + 1);
		}
	}

	currentStateOfQuery = trim(currentStateOfQuery, " \t");

	//for parsing SELECT section
	std::string IDENT = "[A-Za-z]([A-Za-z]|[0-9]|#)*";
	std::string attrName = "(procName|varName|value|stmt#)";
	std::string attrRef = IDENT + "\\." + attrName;
	std::string elem = "(" + IDENT + "|" + attrRef + ")";

	std::regex select1("Select BOOLEAN|Select " + elem + "|Select <\\s?(" + elem + "\\s?,\\s?)+" + elem + "\\s?>");
	std::regex select2("Select BOOLEAN .+|Select " + elem + " .+");
	std::regex select3("Select <\\s?(" + elem + "\\s?,\\s?)+" + elem + "\\s?> .+");

	//Select Part
	if (std::regex_match(currentStateOfQuery, select1)) {
		SelectParsing(currentStateOfQuery);
		return true;
	}
	else if (std::regex_match(currentStateOfQuery, select2)) {
		size_t tPoint = currentStateOfQuery.find_first_of(' ');
		tPoint = currentStateOfQuery.find_first_of(' ', tPoint + 1);
		std::string selectTemp = currentStateOfQuery.substr(0, tPoint);
		currentStateOfQuery = currentStateOfQuery.substr(tPoint + 1, currentStateOfQuery.length());
		SelectParsing(selectTemp);
	}
	else if (std::regex_match(currentStateOfQuery, select3)) {
		size_t tPoint = currentStateOfQuery.find_first_of('>');
		std::string selectTemp = currentStateOfQuery.substr(0, tPoint + 1);
		currentStateOfQuery = currentStateOfQuery.substr(tPoint + 2, currentStateOfQuery.length());
		SelectParsing(selectTemp);
	}
	else {
		isValidQuery = false;
		errorMsg = "Invalid select!";
		return false;
	}

	currentStateOfQuery = trim(currentStateOfQuery, " \t");

	//for parsing relationships/pattern
	std::string stmtRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|([0-9])+)";
	std::string lineRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|([0-9])+)";
	std::string entRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|\"\\s?" + IDENT + "\\s?\"|([0-9])+)";
	std::string varRef = "([A-Za-z]([A-Za-z]|[0-9]|#)*|_|\"\\s?" + IDENT + "\\s?\")";
	std::string expressionSpec = "((\"\\s?((\\w+\\s?(\\+|\\*|-)\\s?)*\\w+)\\s?\")|(_\\s?\"\\s?((\\w+\\s?(\\+|\\*|-)\\s?)*\\w+)\\s?\"\\s?_))";

	std::string followsParent = "(Follows\\s?(\\*)?|Parent\\s?(\\*)?)\\s?\\(\\s?" + stmtRef + "\\s?,\\s?" + stmtRef + "\\s?\\)";
	std::string usesModifies = "(Uses|Modifies)\\s?\\(\\s?(" + entRef + "|" + stmtRef + ")\\s?,\\s?" + varRef + "\\s?\\)";
	std::string calls = "Calls\\s?(\\*)?\\s?\\(\\s?" + entRef + "\\s?,\\s?" + entRef + "\\s?\\)";
	std::string next = "Next\\s?(\\*)?\\s?\\(\\s?" + lineRef + "\\s?,\\s?" + lineRef + "\\s?\\)";
	std::string affects = "Affects\\s?(\\*)?\\s?\\(\\s?" + stmtRef + "\\s?,\\s?" + stmtRef + "\\s?\\)";
	std::string relRef = "(" + followsParent + "|" + usesModifies + "|" + calls + "|" + next + "|" + affects + ")";
	
	std::regex suchThatRelRef("such that " + relRef + "(| .+)");
	std::regex andRelRef("and " + relRef + "(| .+)");

	std::string pattern = IDENT + "\\s?\\(\\s?" + varRef + "\\s?,\\s?(" + expressionSpec + "|_)\\s?(,\\s?_\\s?)?\\)";
	
	std::regex patternPattern("pattern " + pattern + "(| .+)");
	std::regex andPattern("and " + pattern + "(| .+)");

	std::string ref = "(" + attrRef + "|" + IDENT + "|\"" + IDENT + "\"|([0-9])+)";
	std::string attrCompare = ref + "=" + ref;

	std::regex withAttrCompare("with " + attrCompare + "(| .+)");
	std::regex andAttrCompare("and " + attrCompare + "(| .+)");

	//Relationships/Patterns/With part
	int currentClause = 0; //1 = suchthat, 2 = pattern, 3 = with

	while (currentStateOfQuery.compare("") > 0 || currentStateOfQuery.compare("") < 0) {
		if (std::regex_match(currentStateOfQuery, suchThatRelRef)) {
			size_t tPoint = currentStateOfQuery.find_first_of(' ');
			tPoint = currentStateOfQuery.find_first_of(' ', tPoint + 1);
			size_t ePoint = currentStateOfQuery.find_first_of(')');
			std::string relTemp = currentStateOfQuery.substr(tPoint + 1, ePoint - tPoint);
			currentStateOfQuery = currentStateOfQuery.substr(ePoint + 1, currentStateOfQuery.length());
			RelationshipParsing(relTemp);
			currentClause = 1;
		}
		else if (std::regex_match(currentStateOfQuery, andRelRef) && currentClause == 1) {
			size_t tPoint = currentStateOfQuery.find_first_of(' ');
			size_t ePoint = currentStateOfQuery.find_first_of(')');
			std::string relTemp = currentStateOfQuery.substr(tPoint + 1, ePoint - tPoint);
			currentStateOfQuery = currentStateOfQuery.substr(ePoint + 1, currentStateOfQuery.length());
			RelationshipParsing(relTemp);
		}
		else if (std::regex_match(currentStateOfQuery, patternPattern)
			|| (std::regex_match(currentStateOfQuery, andPattern) && currentClause == 2)) {
			size_t tPoint = currentStateOfQuery.find_first_of(' ');
			size_t ePoint = currentStateOfQuery.find_first_of(')');
			std::string relTemp = currentStateOfQuery.substr(tPoint + 1, ePoint - tPoint);
			currentStateOfQuery = currentStateOfQuery.substr(ePoint + 1, currentStateOfQuery.length());
			PatternParsing(relTemp);
			currentClause = 2;
		}
		else if (std::regex_match(currentStateOfQuery, withAttrCompare)
			|| (std::regex_match(currentStateOfQuery, andAttrCompare) && currentClause == 3)) {
			size_t tPoint = currentStateOfQuery.find_first_of(' ');
			size_t ePoint = currentStateOfQuery.find_first_of(' ', tPoint + 1);
			std::string relTemp = currentStateOfQuery.substr(tPoint + 1, ePoint - tPoint);
			if (ePoint == std::string::npos) {
				currentStateOfQuery = "";
			}
			else {
				currentStateOfQuery = currentStateOfQuery.substr(ePoint + 1, currentStateOfQuery.length());
			}
			AttributeParsing(relTemp);
			currentClause = 3;
		}
		else {
			isValidQuery = false;
			errorMsg = "Invalid relationships/patterns/With!";
			return false;
		}
		currentStateOfQuery = trim(currentStateOfQuery, " \t");
	}
	return true;
}

std::list<std::string> QueryParser::queryResult()
{
	if (!isValidQuery) {
		throw std::exception("Invalid query");
	}

	return qp.process(selects, clauses);
}

/*
Example of input string : "assign a1, a2, a3"
*/
bool QueryParser::DeclarationParsing(std::string s)
{
	std::string IDENT = "[A-Za-z]([A-Za-z]|[0-9]|#)*";
	std::regex declarationR1("(assign|call|constant|if|prog_line|procedure|stmt|stmtLst|variable|while)\\s(" + IDENT + "\\s?,\\s?)*" + IDENT);

	std::string trimmed;
	trimmed = trim(s, " \t");

	if (std::regex_match(trimmed, declarationR1)) {
		std::string type, remaining, synTemp;

		type = extractFirstWord(trimmed, " ");
		for (unsigned int i = 0; i < type.length(); i++) { 	//convert to lowercase									 
			type[i] = tolower(type[i]);
		}

		remaining = remainingAfterExtractFirstWord(trimmed, " ") + ',';

		size_t strStart = 0;

		size_t tPoint = remaining.find_first_of(',');
		while (tPoint != std::string::npos) {
			synTemp = remaining.substr(strStart, tPoint - strStart);
			synTemp = trim(synTemp, " \t");

			if (isPresentInSynList(synTemp)) {
				isValidQuery = false;
				errorMsg = "Duplicate synonyms";
				return false;
			}
			else {
				Synonym s;
				s.name = synTemp;
				s.setType(type);
				synonyms.push_back(s);
			}

			strStart = tPoint + 1;
			tPoint = remaining.find_first_of(',', tPoint + 1);
		}
	}
	else {
		isValidQuery = false;
		errorMsg = "Invalid declaration!";
		return false;
	}
	return true;
}

/*
Example of input string : "select a" OR "select boolean" OR "select <a,b,c>"
*/
bool QueryParser::SelectParsing(std::string s)
{
	std::string IDENT = "[A-Za-z]([A-Za-z]|[0-9]|#)*";
	std::string attrName = "(procName|varName|value|stmt#)";
	std::string attrRef = IDENT + "\\." + attrName;
	std::string elem = "(" + IDENT + "|" + attrRef + ")";

	std::regex parseS1("BOOLEAN");
	std::regex parseS2(IDENT);
	std::regex parseS3(attrRef);
	std::regex parseS4("<\\s?(" + elem + "\\s?,\\s?)+" + elem + "\\s?>");

	std::string trimmed, selectType;
	trimmed = trim(s, " \t");
	selectType = trimmed.substr(7, std::string::npos);
	selectType = trim(selectType, " \t");

	if (std::regex_match(selectType, parseS1)) {
		Synonym s;
		s.name = selectType;
		s.setType(selectType);
		selects.push_back(s);
	}
	else if (std::regex_match(selectType, parseS2)) {
		if (isPresentInSynList(selectType)) {
			Synonym s;
			s.name = selectType;
			s.type = getSynTypeFromSynName(selectType);
			selects.push_back(s);
		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	else if (std::regex_match(selectType, parseS3)) {
		std::size_t dotPos = selectType.find_first_of('.');
		std::string syn = trim(selectType.substr(0, dotPos), " \t");
		std::string attrName = trim(selectType.substr(dotPos + 1, selectType.length()), " \t");

		if (isPresentInSynList(syn) && isValidAttrName(syn, attrName)) {
			Synonym s;
			s.name = syn;
			s.type = getSynTypeFromSynName(syn);
			selects.push_back(s);
		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	else if (std::regex_match(selectType, parseS4)) {
		std::size_t posComma = selectType.find_first_of(',');
		std::string elem, syn, attrName;
		std::size_t strStart = 1;
		std::list<std::string> varNameList;

		while (posComma != std::string::npos) {
			elem = selectType.substr(strStart, posComma - strStart);
			elem = trim(elem, " \t");

			if (std::regex_match(elem, parseS2)) {
				syn = elem;
			}
			else if (std::regex_match(elem, parseS3)) {
				std::size_t dotPos = elem.find_first_of('.');
				syn = trim(elem.substr(0, dotPos), " \t");
				attrName = trim(elem.substr(dotPos + 1, elem.length()), " \t");

				if (!isValidAttrName(syn, attrName)) {
					isValidQuery = false;
					return false;
				}
			}

			if (!isPresentInSynList(syn)) {
				isValidQuery = false;
				return false;
			}
			Synonym s;
			s.name = syn;
			s.type = (getSynTypeFromSynName(syn));
			selects.push_back(s);

			strStart = posComma + 1;
			posComma = selectType.find_first_of(',', posComma + 1);
		}

		std::size_t endPos = selectType.find_first_of('>');
		strStart = selectType.find_last_of(',');
		elem = selectType.substr(strStart + 1, endPos - strStart - 1);
		elem = trim(elem, " \t");

		if (std::regex_match(elem, parseS2)) {
			syn = elem;
		}
		else if (std::regex_match(elem, parseS3)) {
			std::size_t dotPos = elem.find_first_of('.');
			syn = trim(elem.substr(0, dotPos), " \t");
			attrName = trim(elem.substr(dotPos + 1, elem.length()), " \t");

			if (!isValidAttrName(syn, attrName)) {
				isValidQuery = false;
				return false;
			}
		}

		if (!isPresentInSynList(syn)) {
			isValidQuery = false;
			return false;
		}
		Synonym s;
		s.name = syn;
		s.type = (getSynTypeFromSynName(syn));
		selects.push_back(s);

	}
	else {
		isValidQuery = false;
		errorMsg = "Invalid select!";
		return false;
	}
	return true;
}

/*
Example of input string : "Follows* (a, 2)"
*/
bool QueryParser::RelationshipParsing(std::string s)
{
	std::string relT, arg1, arg2;
	bool hasAsterisk = false;

	size_t tPointStartingBracket = s.find_first_of('(');
	size_t tPointEndingBracket = s.find_first_of(')');
	size_t tPointComma = s.find_first_of(',');

	relT = s.substr(0, tPointStartingBracket);
	arg1 = s.substr(tPointStartingBracket + 1, tPointComma - tPointStartingBracket - 1);
	arg2 = s.substr(tPointComma + 1, tPointEndingBracket - tPointComma - 1);

	relT = trim(relT, " \t");
	arg1 = trim(arg1, " \t");
	arg2 = trim(arg2, " \t");

	//relT parsing
	size_t foundAsterisk = relT.find('*');
	if (foundAsterisk != std::string::npos) {
		hasAsterisk = true;
		relT = relT.substr(0, foundAsterisk);
		relT = trim(relT, " \t");
	}

	std::string IDENT = "[A-Za-z]([A-Za-z]|[0-9]|#)*";
	std::regex r1(IDENT);
	std::regex r2("_");
	std::regex r3("([0-9])+");
	std::regex r4("\"\\s?" + IDENT + "\\s?\"");


	ArgType stArg1 = ArgType::NIL;
	ArgType stArg2 = ArgType::NIL;

	//arg1 parsing
	if (std::regex_match(arg1, r1)) {
		if (isPresentInSynList(arg1)) {
			stArg1 = getSynTypeFromSynName(arg1);
		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	else if (std::regex_match(arg1, r4)) {
		arg1 = trim(arg1, "\" \t");
	}

	//arg2 parsing
	if (std::regex_match(arg2, r1)) {
		if (isPresentInSynList(arg2)) {
			stArg2 = getSynTypeFromSynName(arg2);
		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	else if (std::regex_match(arg2, r4)) {
		arg2 = trim(arg2, "\" \t");
	}

	if (relT.compare("Parent") == 0) {
		if (stArg1 != ArgType::WHILE && stArg1 != ArgType::IF && stArg1 != ArgType::STMT
			&& stArg1 != ArgType::PROG_LINE && stArg1 != ArgType::NIL) {
			isValidQuery = false;
			return false;
		}
		if (stArg2 == ArgType::VARIABLE || stArg2 == ArgType::CONSTANT || stArg2 == ArgType::PROCEDURE
			|| stArg2 == ArgType::STMTLST) {
			isValidQuery = false;
			return false;
		}
		if (std::regex_match(arg1, r2)) {
			stArg1 = ArgType::STMT;
			arg1 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
		if (std::regex_match(arg2, r2)) {
			stArg2 = ArgType::STMT;
			arg2 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
	}
	else if (relT.compare("Follows") == 0) {
		if (stArg1 == ArgType::VARIABLE || stArg1 == ArgType::CONSTANT || stArg2 == ArgType::PROCEDURE
			|| stArg1 == ArgType::STMTLST) {
			isValidQuery = false;
			return false;
		}
		if (stArg2 == ArgType::VARIABLE || stArg2 == ArgType::CONSTANT || stArg2 == ArgType::PROCEDURE
			|| stArg2 == ArgType::STMTLST) {
			isValidQuery = false;
			return false;
		}
		if (std::regex_match(arg1, r2)) {
			stArg1 = ArgType::STMT;
			arg1 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
		if (std::regex_match(arg2, r2)) {
			stArg2 = ArgType::STMT;
			arg2 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
	}
	else if (relT.compare("Uses") == 0) {
		if (stArg1 == ArgType::VARIABLE || stArg1 == ArgType::CONSTANT || stArg1 == ArgType::STMTLST) {
			isValidQuery = false;
			return false;
		}
		if (stArg2 != ArgType::VARIABLE && stArg2 != ArgType::NIL) {
			isValidQuery = false;
			return false;
		}

		//checks for underscore as it can refer to stmt or proc
		if (std::regex_match(arg1, r2)) {
			isValidQuery = false;
			return false;
		}
		if (std::regex_match(arg2, r2)) {
			stArg2 = ArgType::VARIABLE;
			arg2 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}

	}
	else if (relT.compare("Modifies") == 0) {
		if (stArg1 == ArgType::VARIABLE || stArg1 == ArgType::CONSTANT || stArg1 == ArgType::STMTLST) {
			isValidQuery = false;
			return false;
		}
		if (stArg2 != ArgType::VARIABLE && stArg2 != ArgType::NIL) {
			isValidQuery = false;
			return false;
		}

		//checks for underscore as it can refer to stmt or proc
		if (std::regex_match(arg1, r2)) {
			isValidQuery = false;
			return false;
		}
		if (std::regex_match(arg2, r2)) {
			stArg2 = ArgType::VARIABLE;
			arg2 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
	}
	else if (relT.compare("Calls") == 0) {
		if (stArg1 != ArgType::PROCEDURE && stArg1 != ArgType::NIL) {
			isValidQuery = false;
			return false;
		}
		if (stArg2 != ArgType::PROCEDURE && stArg2 != ArgType::NIL) {
			isValidQuery = false;
			return false;
		}
		//Calls cannot have integers as parameters
		if (std::regex_match(arg1, r3) || std::regex_match(arg2, r3)) {
			isValidQuery = false;
			return false;
		}
		if (std::regex_match(arg1, r2)) {
			stArg1 = ArgType::PROCEDURE;
			arg1 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
		if (std::regex_match(arg2, r2)) {
			stArg2 = ArgType::PROCEDURE;
			arg2 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
	}
	else if (relT.compare("Next") == 0) {
		if (stArg1 == ArgType::VARIABLE || stArg1 == ArgType::CONSTANT || stArg1 == ArgType::PROCEDURE
			|| stArg1 == ArgType::STMTLST) {
			isValidQuery = false;
			return false;
		}
		if (stArg2 == ArgType::VARIABLE || stArg2 == ArgType::CONSTANT || stArg2 == ArgType::PROCEDURE
			|| stArg2 == ArgType::STMTLST) {
			isValidQuery = false;
			return false;
		}
		if (std::regex_match(arg1, r2)) {
			stArg1 = ArgType::STMT;
			arg1 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
		if (std::regex_match(arg2, r2)) {
			stArg2 = ArgType::STMT;
			arg2 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
	}
	else if (relT.compare("Affects") == 0) {
		if (stArg1 != ArgType::ASSIGN && stArg1 != ArgType::STMT && stArg1 != ArgType::PROG_LINE
			&& stArg1 != ArgType::NIL) {
			isValidQuery = false;
			return false;
		}
		if (stArg2 != ArgType::ASSIGN && stArg2 != ArgType::STMT && stArg2 != ArgType::PROG_LINE
			&& stArg2 != ArgType::NIL) {
			isValidQuery = false;
			return false;
		}
		if (std::regex_match(arg1, r2)) {
			stArg1 = ArgType::ASSIGN;
			arg1 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
		if (std::regex_match(arg2, r2)) {
			stArg2 = ArgType::ASSIGN;
			arg2 = std::to_string(argTypeIndexCount);
			argTypeIndexCount++;
		}
	}
	Synonym s1, s2;
	s1.name = arg1;
	s1.type = stArg1;
	s2.name = arg2;
	s2.type = stArg2;

	Clause c;
	c.arg1 = s1;
	c.arg2 = s2;
	c.setType(relT);
	c.asterisk = hasAsterisk;

	clauses.push_back(c);
	return true;
}
/*
Example of input string : "a(_,"x+12")"
*/
bool QueryParser::PatternParsing(std::string s)
{
	std::string IDENT = "[A-Za-z]([A-Za-z]|[0-9]|#)*";
	std::regex r1(IDENT);
	std::regex r2("_");
	std::regex r3("\"\\s?" + IDENT + "\\s?\"");

	std::string patternT, arg1, arg2;
	bool hasUnderscoresBothSides = false;

	size_t tPointStartingBracket = s.find_first_of('(');
	size_t tPointEndingBracket = s.find_first_of(')');
	size_t tPointComma = s.find_first_of(',');

	patternT = s.substr(0, tPointStartingBracket);
	arg1 = s.substr(tPointStartingBracket + 1, tPointComma - tPointStartingBracket - 1);
	arg2 = s.substr(tPointComma + 1, tPointEndingBracket - tPointComma - 1);

	patternT = trim(patternT, " \t");
	arg1 = trim(arg1, " \t");
	arg2 = trim(arg2, " \t");

	//arg1 parsing
	ArgType stArg1 = ArgType::NIL;

	if (std::regex_match(arg1, r1)) {
		if (isPresentInSynList(arg1)) {
			stArg1 = getSynTypeFromSynName(arg1);
		}
		else {
			isValidQuery = false;
			return false;
		}
		if (stArg1 != ArgType::VARIABLE) {
			isValidQuery = false;
			return false;
		}
	}
	else if (std::regex_match(arg1, r2)) {
		stArg1 = ArgType::VARIABLE;
		arg1 = std::to_string(argTypeIndexCount);
		argTypeIndexCount++;
	}
	else if (std::regex_match(arg1, r3)) {
		arg1 = trim(arg1, "\" \t");
	}

	//pattern type parsing

	ArgType stPatternT = ArgType::NIL;

	if (isPresentInSynList(patternT)) {
		stPatternT = getSynTypeFromSynName(patternT);
	}
	else {
		isValidQuery = false;
		return false;
	}

	//arg2 parsing
	std::regex e1("\"\\s?.+\\s?\"");
	std::regex e2("_\\s?\"\\s?.+\\s?\"\\s?_");
	std::regex e3("_");
	std::regex e4("_\\s?,\\s?_");
	std::regex e5("\\s");
	if (stPatternT == ArgType::ASSIGN) {
		if (std::regex_match(arg2, e1)) {
			arg2 = trim(arg2, "\" \t");
			arg2 = std::regex_replace(arg2, e5, "");
		}
		else if (std::regex_match(arg2, e2)) {
			hasUnderscoresBothSides = true;
			arg2 = trim(arg2, "\"_ \t");
			arg2 = std::regex_replace(arg2, e5, "");
		}
		else if (std::regex_match(arg2, e3)) {

		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	else if (stPatternT == ArgType::IF) {
		if (std::regex_match(arg2, e4)) {

		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	else if (stPatternT == ArgType::WHILE) {
		if (std::regex_match(arg2, e3)) {

		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	else {
		isValidQuery = false;
		return false;
	}
	Synonym s1, s2, sPattern;
	s1.name = arg1;
	s1.type = stArg1;
	s2.name = arg2;
	sPattern.name = patternT;
	sPattern.type = stPatternT;

	Clause c;
	c.arg1 = s1;
	c.arg2 = s2;
	c.setType("pattern");
	c.patternSyn = sPattern;
	c.patternUnderscore = hasUnderscoresBothSides;

	clauses.push_back(c);

	return true;
}

/*
Example of input string : "a.stmt# = c.value"
*/
bool QueryParser::AttributeParsing(std::string s)
{
	std::string IDENT = "[A-Za-z]([A-Za-z]|[0-9]|#)*";
	std::string attrName = "(procName|varName|value|stmt#)";
	std::regex attrRef(IDENT + "\\." + attrName);
	std::regex synonym(IDENT);
	std::regex charString("\"" + IDENT + "\"");
	std::regex integer("([0-9])+");

	std::string ref1, ref2;
	std::string ref1Syn, ref2Syn;
	std::string ref1AttrName, ref2AttrName;
	std::string temp;
	ArgType ref1SynType = ArgType::NIL;
	ArgType ref2SynType = ArgType::NIL;
	size_t dotPos;

	size_t equalPos = s.find_first_of('=');
	ref1 = trim(s.substr(0, equalPos), " \t");
	ref2 = trim(s.substr(equalPos + 1, s.length()), " \t");

	//changing positions of ref1 and ref2 
	//1st condition: anything\attrRef = attrRef -> attrRef = anything\attrRef
	//2nd condition: anything\attrRef\synonym = synonym -> synonym = anything\attrRef\synonym
	if (!std::regex_match(ref1, attrRef)) {
		if (std::regex_match(ref2, attrRef) ||
			(!std::regex_match(ref1, synonym) && std::regex_match(ref2, synonym))) {
			ref1.swap(ref2);
		}
	}

	//ref1 => attrRef
	if (std::regex_match(ref1, attrRef)) {
		dotPos = ref1.find_first_of('.');
		ref1Syn = trim(ref1.substr(0, dotPos), " \t");
		ref1AttrName = trim(ref1.substr(dotPos + 1, ref1.length()), " \t");

		if (!isValidAttrName(ref1Syn, ref1AttrName)) {
			isValidQuery = false;
			return false;
		}
		else {
			ref1SynType = getSynTypeFromSynName(ref1Syn);
		}

		//ref2 =>attrRef
		if (std::regex_match(ref2, attrRef)) {
			dotPos = ref2.find_first_of('.');
			ref2Syn = trim(ref2.substr(0, dotPos), " \t");
			ref2AttrName = trim(ref2.substr(dotPos + 1, ref2.length()), " \t");

			if (!isValidAttrName(ref2Syn, ref2AttrName)) {
				isValidQuery = false;
				return false;
			}
			else {
				ref2SynType = getSynTypeFromSynName(ref2Syn);
			}
			//check LHS and RHS same type
			if (ref1AttrName.compare("procName") == 0 || ref1AttrName.compare("varName") == 0) {
				if (ref2AttrName.compare("value") == 0 || ref2AttrName.compare("stmt#") == 0) {
					isValidQuery = false;
					return false;
				}
			}
			else {
				if (ref2AttrName.compare("procName") == 0 || ref2AttrName.compare("varName") == 0) {
					isValidQuery = false;
					return false;
				}
			}

			//check for exact same symName return false?

		}
		//ref2 => synonym
		else if (std::regex_match(ref2, synonym)) {
			ref2Syn = ref2;
			if (isPresentInSynList(ref2)) {
				ref2SynType = getSynTypeFromSynName(ref2);
				if (ref2SynType != ArgType::PROG_LINE) {
					isValidQuery = false;
					return false;
				}
				if (ref1AttrName.compare("procName") == 0 || ref1AttrName.compare("varName") == 0) {
					isValidQuery = false;
					return false;
				}
			}
			else {
				isValidQuery = false;
				return false;
			}
		}
		//ref2 => charString
		else if (std::regex_match(ref2, charString)) {
			ref2Syn = trim(ref2, "\" \t");
			if (ref1AttrName.compare("value") == 0 || ref1AttrName.compare("stmt#") == 0) {
				isValidQuery = false;
				return false;
			}
		}
		//ref2 => integer
		else if (std::regex_match(ref2, integer)) {
			ref2Syn = ref2;
			if (ref1AttrName.compare("procName") == 0 || ref1AttrName.compare("varName") == 0) {
				isValidQuery = false;
				return false;
			}
		}
		else {
			isValidQuery = false;
			return false;
		}
	}
	//ref1 => synonym
	else if (std::regex_match(ref1, synonym)) {
		ref1Syn = ref1;
		ref2Syn = ref2;
		if (isPresentInSynList(ref1)) {
			ref1SynType = getSynTypeFromSynName(ref1);
			if (ref1SynType != ArgType::PROG_LINE) {
				isValidQuery = false;
				return false;
			}
			//ref2 => attrRef
			if (std::regex_match(ref2, attrRef)) {

			}
			//ref2 => synonym
			else if (std::regex_match(ref2, synonym)) {
				if (isPresentInSynList(ref2)) {
					ref2SynType = getSynTypeFromSynName(ref2);
					if (ref2SynType != ArgType::PROG_LINE) {
						isValidQuery = false;
						return false;
					}
				}
				else {
					isValidQuery = false;
					return false;
				}
			}
			//ref2 => charString
			else if (std::regex_match(ref2, charString)) {
				isValidQuery = false;
				return false;
			}
			//ref2 => integer
			else if (std::regex_match(ref2, integer)) {

			}
		}
		else {
			isValidQuery = false;
			return false;
		}

	}
	//ref1 => charString
	else if (std::regex_match(ref1, charString)) {
		ref1Syn = trim(ref1, "\" \t");
		ref2Syn = ref2;
		if (std::regex_match(ref2, attrRef)) {

		}
		//ref2 => synonym
		else if (std::regex_match(ref2, synonym)) {

		}
		//ref2 => charString
		else if (std::regex_match(ref2, charString)) {
			ref2Syn = trim(ref2, "\" \t");
		}
		//ref2 => integer
		else if (std::regex_match(ref2, integer)) {
			isValidQuery = false;
			return false;
		}

	}
	//ref1 => INTEGER
	else if (std::regex_match(ref1, integer)) {
		ref1Syn = ref1;
		ref2Syn = ref2;
		if (std::regex_match(ref2, attrRef)) {

		}
		//ref2 => synonym
		else if (std::regex_match(ref2, synonym)) {

		}
		//ref2 => charString
		else if (std::regex_match(ref2, charString)) {
			isValidQuery = false;
			return false;
		}
		//ref2 => integer
		else if (std::regex_match(ref2, integer)) {

		}
	}
	else {
		isValidQuery = false;
		return false;
	}

	Synonym s1, s2;
	s1.name = ref1Syn;
	s1.type = ref1SynType;
	s2.name = ref2Syn;
	s2.type = ref2SynType;

	Clause c;
	c.arg1 = s1;
	c.arg2 = s2;
	c.setType("with");

	clauses.push_back(c);

	return true;
}

bool QueryParser::getIsValidQuery()
{
	return isValidQuery;
}

std::string QueryParser::getQuery()
{
	return query;
}

std::string QueryParser::getErrorMsg()
{
	return errorMsg;
}

std::vector<Synonym> QueryParser::getSynonymList()
{
	return synonyms;
}

std::vector<Synonym> QueryParser::getSelectList()
{
	return selects;
}

std::vector<Clause> QueryParser::getClausesList()
{
	return clauses;
}

void QueryParser::setIsValidQuery(bool isValid)
{
	isValidQuery = isValid;
}

/*
Checks if synonymName is present in the list of declared synonyms
*/
bool QueryParser::isPresentInSynList(std::string type) {
	std::vector<Synonym>::iterator iterator;
	for (iterator = synonyms.begin(); iterator != synonyms.end(); ++iterator) {
		if (iterator->name.compare(type) == 0) {
			return true;
		}
	}
	return false;
}

ArgType QueryParser::getSynTypeFromSynName(std::string type)
{
	std::vector<Synonym>::iterator iterator;
	for (iterator = synonyms.begin(); iterator != synonyms.end(); ++iterator) {
		if (iterator->name.compare(type) == 0) {
			return iterator->type;
		}
	}
	return ArgType::NIL;
}

bool QueryParser::isValidAttrName(std::string syn, std::string attrName)
{
	ArgType synType;
	if (isPresentInSynList(syn)) {
		synType = getSynTypeFromSynName(syn);

		if (synType == ArgType::ASSIGN) {
			if (attrName.compare("stmt#") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::CALL) {
			if (attrName.compare("stmt#") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::CONSTANT) {
			if (attrName.compare("value") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::IF) {
			if (attrName.compare("stmt#") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::PROCEDURE) {
			if (attrName.compare("procName") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::PROG_LINE) {
			if (attrName.compare("stmt#") == 0) {
				return true;
			}
			if (attrName.compare("value") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::STMT) {
			if (attrName.compare("stmt#") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::STMTLST) {
			if (attrName.compare("stmt#") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::VARIABLE) {
			if (attrName.compare("varName") == 0) {
				return true;
			}
		}
		else if (synType == ArgType::WHILE) {
			if (attrName.compare("stmt#") == 0) {
				return true;
			}
		}
	}
	return false;
}

/*
Remove whitespaces from both ends of the string
*/
std::string QueryParser::trim(std::string s, std::string whitespace)
{
	auto strBegin = s.find_first_not_of(whitespace);
	if (strBegin == std::string::npos) {
		return ""; //no content
	}

	auto strEnd = s.find_last_not_of(whitespace);
	auto strRange = strEnd - strBegin + 1;

	return s.substr(strBegin, strRange);
}

/*
Input: "assign a, b, c"
Returns: "assign"
*/
std::string QueryParser::extractFirstWord(std::string s, std::string delimiter)
{
	auto strEnd = s.find_first_of(delimiter);

	return s.substr(0, strEnd);
}

/*
Input: "assign a, b, c"
Returns: "a, b, c"
*/
std::string QueryParser::remainingAfterExtractFirstWord(std::string s, std::string delimiter)
{
	auto strEnd = s.find_first_of(delimiter);
	auto strRange = s.length() - strEnd;
	return s.substr(strEnd + 1, strRange);
}

std::string QueryParser::trimExcessSpaces(std::string s)
{
	std::string result;
	std::regex r1("\\s{2,}");
	result = std::regex_replace(s, r1, " ");
	std::regex r2("\\s?\\.\\s?");
	result = std::regex_replace(result, r2, ".");
	std::regex r3("\\s?=\\s?");
	result = std::regex_replace(result, r3, "=");

	//remove front and back whitespaces in " "
	size_t firstQuote = 0;
	size_t secondQuote = -1;
	while (true) {
		firstQuote = result.find_first_of('\"', secondQuote + 1);
		if (firstQuote == std::string::npos) {
			break;
		}
		if (result.substr(firstQuote + 1, 1).compare(" ") == 0) {
			result.erase(firstQuote + 1, 1);
		}

		secondQuote = result.find_first_of('\"', firstQuote + 1);
		if (secondQuote == std::string::npos) {
			break;
		}
		if (result.substr(secondQuote - 1, 1).compare(" ") == 0) {
			result.erase(secondQuote - 1, 1);
		}
	}
	return result;
}

bool QueryParser::testRegex(std::string s, std::string regexS)
{
	std::regex r1(regexS);

	return std::regex_match(s, r1);
}




