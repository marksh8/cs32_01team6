#include "Attribute.h"



Attribute::Attribute()
{
}


Attribute::~Attribute()
{
}
