#pragma once
#include <vector>
#include "Statement.h"

class Variable;
class Statement;

class Procedure 
{
public:
	Procedure(const std::string& name);
	~Procedure();

	const std::string name;
	//const unsigned int start_line;
	Statement* current_container; //when adding statement, we need to know the stmtLst that it belongs to
	std::set<Procedure*> callerStack;
	std::set<Statement*> callerStmts;
	std::set<Procedure*> calleeStack;
	std::set<Procedure*> directCallers;
	std::set<Procedure*> directCallees;

	std::vector<Statement*> childList;
	std::vector<Statement*> parentStack;
	std::set<Variable*> usedVars;
	std::set<Variable*> modifiedVars;

	void addChild(Statement* child);
	void addToUse(Variable* varName);
	void addToModify(Variable* varName);

	void addCaller(Procedure* caller);
	void addCallerStmt(Statement* stmt);
	void addCallee(Procedure* callee);
	void addDirectCaller(Procedure* caller);
	void addDirectCallee(Procedure* callee);

	std::set<std::string> getAllUsesVar();
	std::set<std::string> getAllModifiesVar();

	std::set<std::string> getAllCallers();
	std::set<std::string> getAllCallees();
	std::set<std::string> getAllDirectCallers();
	std::set<std::string> getAllDirectCallees();

	//Queries
	bool ifUse(Variable* var);
	bool ifModify(Variable* var);
	bool ifDirectCalledBy(Procedure* caller);
	bool ifDirectCall(Procedure* callee);
	bool ifCalledBy(Procedure* caller);
	bool ifCall(Procedure* callee);
};

