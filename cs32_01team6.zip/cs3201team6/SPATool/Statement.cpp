#include "Procedure.h"

Statement::Statement(unsigned int line_number) : line_number(line_number)
{
	parent = nullptr;
	leftSibling = nullptr;
	rightSibling = nullptr;
	next[0] = nullptr;
	next[1] = nullptr;
}

Statement::~Statement()
{
	if (leftSibling != nullptr)
	{
		leftSibling->rightSibling = nullptr;
	}

	if (rightSibling != nullptr)
	{
		rightSibling->leftSibling = nullptr;
	}

	for (Statement* child : childList)
	{
		delete child;
	}

}

void Statement::addNextToIfRightSibling(Statement* If, Statement* rs)
{
	int lastThenChildIndex = If->firstElseChildIndex - 1;
	if (If->childList[lastThenChildIndex]->type != stmt_type::type_if)
	{
		if (If->childList[lastThenChildIndex]->next[0] == nullptr)
		{
			If->childList[lastThenChildIndex]->next[0] = rs;
		}
		else
		{
			If->childList[lastThenChildIndex]->next[1] = rs;
		}
		rs->prev.push_back(If->childList[lastThenChildIndex]);
	}
	else
	{
		addNextToIfRightSibling(If->childList[lastThenChildIndex], rs);
	}
	if (If->childList.back()->type != stmt_type::type_if)
	{
		if (If->childList.back()->next[0] == nullptr)
		{
			If->childList.back()->next[0] = rs;
		}
		else
		{
			If->childList.back()->next[1] = rs;
		}
		rs->prev.push_back(If->childList.back());
	}
	else
	{
		addNextToIfRightSibling(If->childList.back(), rs);
	}
}


void Statement::addChild(Statement * child)
{
	child->parent = this;

	if (!childList.empty())
	{
		child->leftSibling = childList.back();
		childList.back()->rightSibling = child;
		if (child->leftSibling->type != stmt_type::type_if)
		{
			if (child->leftSibling->type == stmt_type::type_while)
			{
				child->leftSibling->next[1] = child;
			}
			else
			{
				child->leftSibling->next[0] = child;
			}
			child->prev.push_back(child->leftSibling);
		}
		else
		{
			addNextToIfRightSibling(child->leftSibling, child);
		}
	}
	else
	{
		this->next[0] = child;
		child->prev.push_back(this);
	}
	childList.push_back(child);
}

void Statement::addToUse(Variable* varName)
{
	usedVars.insert(varName);
	varName->addToUse(this);
	if (!ancestors.empty())
	{
		for (unsigned int i = 0; i < ancestors.size(); i++)
		{
			ancestors.at(i)->usedVars.insert(varName);
			varName->addToUse(ancestors.at(i));
		}
	}
}

void Statement::addToModify(Variable* varName)
{
	modifiedVars.insert(varName);
	varName->addToModify(this);
	if (!ancestors.empty())
	{
		for (unsigned int i = 0; i < ancestors.size(); i++)
		{
			ancestors.at(i)->modifiedVars.insert(varName);
			varName->addToModify(ancestors.at(i));
		}
	}
}

std::set<std::string> Statement::getAllUsesVar()
{
	std::set<std::string> result;
	for (std::set<Variable*>::iterator it = usedVars.begin(); it != usedVars.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

std::set<std::string> Statement::getAllModifiesVar()
{
	std::set<std::string> result;
	for (std::set<Variable*>::iterator it = modifiedVars.begin(); it != modifiedVars.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

bool Statement::ifUse(Variable* var)
{
	return usedVars.find(var) != usedVars.end();
}

bool Statement::ifModify(Variable* var)
{
	return modifiedVars.find(var) != modifiedVars.end();
}

bool Statement::fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore)
{
	return false;
}
