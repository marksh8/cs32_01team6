#include "QueryEvaluator.h"
#include <sstream>
#include <iterator>
#include <stack>
#include <cassert>

bool operator==(const PKBQuery& lhs, const PKBQuery& rhs) {
    return std::tie(lhs.type, lhs.asterisk, lhs.left, lhs.right, lhs.pattern)
            == std::tie(rhs.type, rhs.asterisk, rhs.left, rhs.right, rhs.pattern);
}

size_t PKBQueryHash::operator() (const PKBQuery &pkbQuery) const {
    size_t hash = static_cast<std::size_t>(pkbQuery.type);
    hash_combine(hash, pkbQuery.asterisk);
    hash_combine(hash, pkbQuery.left);
    hash_combine(hash, pkbQuery.right);
	hash_combine(hash, pkbQuery.patternUnderscore);
    hash_combine(hash, pkbQuery.pattern);
    return hash;
}

template <class T>
inline void hash_combine(std::size_t& seed, const T& v) {
	std::hash<T> hasher;
	seed ^= hasher(v) + 0x9e3779b9 + (seed << 6) + (seed >> 2);
}

QueryEvaluator::QueryEvaluator() : pkb(ProgramKnowledgeBase::getInstance()) {}

QueryEvaluator::~QueryEvaluator() {
	clean();
}

std::list<std::string> QueryEvaluator::process(const std::vector<Synonym>& selected,
                                                 const std::vector<Clause>& clauses) {
    assert(selected.size() > 0);
    bool selected_boolean = false;
    if (selected.size() == 1 && selected[0].type == ArgType::BOOLEAN) {
        selected_boolean = true;
    } else {
        addSelected(selected);
    }
    addEdges(clauses);
    
    //phase 1: reduce domin: O(m^2*n^3*r), m = no of clause, n = no of item, r = validate clause
    
    //bool: true for cheching right (left unchange)
    std::set<std::pair<DepEdge*, bool>> priority_queue;
    for (auto item : edges_) {
        priority_queue.insert(std::make_pair(item, false));
        priority_queue.insert(std::make_pair(item, true));
    }
    
	//this function remove and return the edge (clause) with smallest complexity
    auto popPriorityQueue = [this, &priority_queue]() -> std::pair<DepEdge*, bool> {
		//this is the function compare the complexity of two clauses
        auto compare = [this](const std::pair<DepEdge*, bool>& lhs, const std::pair<DepEdge*, bool>& rhs) {
            auto getScore = [this](const DepEdge& edge) {                
                auto getNumberOfReminingDomin = [this](const DepEdge& edge) {
                    return nodes_[edge.left].domin.size() * nodes_[edge.right].domin.size();
                };
                
                unsigned int score = getNumberOfReminingDomin(edge);
				if (edge.type == ClauseType::AFFECTS) {
					score *= pkb.getAllStmt().size();
				}
                
                return score;
            };
            
            return getScore(*lhs.first) < getScore(*rhs.first);
        };
        
        auto top = std::min_element(priority_queue.begin(), priority_queue.end(), compare);
		auto res = *top;
        priority_queue.erase(top);
        return res;
    };
    
    while (!priority_queue.empty()) {
        const auto& edge = popPriorityQueue();
        auto& left = nodes_[edge.first->left].domin;
        auto& right = nodes_[edge.first->right].domin;
        auto changed = edge.second ? checkRight(edge.first, left, right) : checkLeft(edge.first, left, right);
        if (changed) {
            auto item = edge.second ? edge.first->right : edge.first->left;     //changed item
            auto& node = nodes_[item];
            if (node.domin.empty()) {
                if (selected_boolean) {
                    return false_result;
                } else {
                    return none_result;
                }
            }
            priority_queue.insert(node.deps.begin(), node.deps.end());
        }
    }
    
    priority_queue.clear();
    
    //phase 2: search (now every value in the domin is useful)
    
    if (selected_boolean) {
        return true_result;
    }
    
	std::list<std::string> results;   //final results

    ValueMap remaining_values;
    for (auto item : nodes_) {
        remaining_values[item.first] = item.second.domin;   //copy
    }
    
    recursiveSearch(results, remaining_values, 0);
	
	//it seems that recursive one is faster than explict stack
	//stackSearch(results);

    //return
    clean();
    return results;
}

void QueryEvaluator::recursiveSearch(std::list<std::string>& results,
                                       const ValueMap& remaining_values,
                                       unsigned int level) {
    
    const auto& node = selected_[level];
    const auto& domin = nodes_[node].domin;
    for (auto value : domin) {
        auto values = remaining_values;     //copy
        auto res = setAndReduceValues(values, node, value);
        if (res) {
            if (level == selected_.size() - 1) {
                std::vector<std::string> result;
                for (auto item : selected_) {
                    result.push_back(*values[item].begin());   //should have exactly one value
                }
                results.push_back(wrapResult(result));
            } else {
                recursiveSearch(results, values, level + 1);
            }
        }
    }
}

void QueryEvaluator::stackSearch(std::list<std::string>& results) {
    std::stack<std::pair<std::string, size_t>> search_stack;  //size_t for level (position for selected item)
    
    auto addToStack = [this, &search_stack](size_t level) -> bool {
        if (level >= selected_.size()) {
            return false;
        }
        
        const auto& node = selected_[level];
        const auto& domin = nodes_[node].domin;
        for (auto riter = domin.rbegin(); riter != domin.rend(); ++riter) {
            search_stack.push(std::make_pair(*riter, level));
        }
        return true;
    };
    
    auto popStack = [&search_stack]() -> std::pair<std::string, size_t> {
        auto item = search_stack.top();
        search_stack.pop();
        return item;
    };
    
    std::vector<ValueMap> values;   //per level
    values.push_back(ValueMap());
    for (auto item : nodes_) {
        values[0][item.first] = item.second.domin;   //copy
    }
    
    std::vector<std::string> result;    //one result before warp to string
    addToStack(0);    //there is at least one
    
    while (!search_stack.empty()) {
        auto item = popStack();
        auto values_cur_level = values[item.second];
        auto res = setAndReduceValues(values_cur_level, selected_[item.second], item.first);
        if(res) {
            if (!addToStack(item.second + 1)) {     //end of elected
                std::vector<std::string> result;
                for (auto item : selected_) {
                    result.push_back(*values_cur_level[item].begin());   //should have exactly one value
                }
                results.push_back(wrapResult(result));
            } else {
                if (values.size() == item.second + 1) {
                    values.push_back(values_cur_level);
                } else {
                    values[item.second + 1] = values_cur_level;
                }
            }
        }
    }
}

void QueryEvaluator::addSelected(const std::vector<Synonym>& syns) {
    for (auto syn : syns) {
        auto& node = nodes_[syn.name];
        initNodeWithArgType(node, syn.type);
        selected_.push_back(syn.name);
    }
}

void QueryEvaluator::addEdges(const std::vector<Clause>& clauses) {
    auto addArg = [this](const Synonym& syn) {
        static unsigned int curConst = 0;
        std::string name;
        if (syn.type == ArgType::NIL) {     //const
            name = std::to_string(++curConst) + "c";    //simple non-repeatable name
            nodes_[name].domin.insert(syn.name);
        } else {
            name = syn.name;
            if (nodes_.find(name) == nodes_.end()) {
                this->initNodeWithArgType(nodes_[name], syn.type);
            }
        }
        return name;
    };
    
    std::string name1;
    std::string name2;
    std::string pattern;
	bool patternUnderscore = false;
    
    for (auto clause : clauses) {
        if (clause.type == ClauseType::PATTERN) {
            name1 = addArg(clause.patternSyn);
            name2 = addArg(clause.arg1);
            pattern = clause.arg2.name;
			patternUnderscore = clause.patternUnderscore;
        } else {
            name1 = addArg(clause.arg1);
            if (clause.arg2 != clause.arg1) {   //reduce searching time
                name2 = addArg(clause.arg2);
            } else {
                name2 = name1;
            }
        }
        
        auto dep_edge = new DepEdge({clause.type, clause.asterisk, name1, name2, patternUnderscore, pattern});
        edges_.push_back(dep_edge);
        nodes_[name1].deps.insert(std::make_pair(edges_.back(), true));
        nodes_[name2].deps.insert(std::make_pair(edges_.back(), false));
    }
}

bool QueryEvaluator::setAndReduceValues(ValueMap& values, const std::string& node, const std::string& value) {
    auto& nodeValues = values[node];
    nodeValues.clear();
    nodeValues.insert(value);
    
    const auto& deps = nodes_[node].deps;
    for (auto edge : deps) {
        auto& left = values[edge.first->left];
        auto& right = values[edge.first->right];
        auto changed = edge.second ? checkRight(edge.first, left, right) :
        checkLeft(edge.first, left, right);
        if (changed) {
            auto item = edge.second ? edge.first->right : edge.first->left;     //changed item
            if (values[item].empty()) {
                return false;
            }
        }
    }
    return true;
}

bool QueryEvaluator::checkLeft(DepEdge* edge, std::set<std::string>& left, std::set<std::string>& right) {
    auto iter = left.begin();
    bool changed = false;
    while (iter != left.end()) {
        bool no_matching = true;
        for (auto item_right : right) {
            auto res = test({edge->type, edge->asterisk, *iter, item_right, edge->patternUnderscore, edge->pattern});
            if (res) {
                no_matching = false;
                break;
            }
        }
        if (no_matching) {
            iter = left.erase(iter);
            changed = true;
        } else {
            ++iter;
        }
    }
    return changed;
}

bool QueryEvaluator::checkRight(DepEdge* edge, std::set<std::string>& left, std::set<std::string>& right) {
    auto iter = right.begin();
    bool changed = false;
    while (iter != right.end()) {
        bool no_matching = true;
        for (auto item_left : left) {
            auto res = test({edge->type, edge->asterisk, item_left, *iter, edge->patternUnderscore , edge->pattern});
            if (res) {
                no_matching = false;
                break;
            }
        }
        if (no_matching) {
            iter = right.erase(iter);
            changed = true;
        } else {
            ++iter;
        }
    }
    return changed;
}

inline std::string QueryEvaluator::wrapResult(const std::vector<std::string>& result) const {
    if (result.empty()) {
        return std::string();
    }
    if (result.size() == 1) {
        return result[0];
    }
    
    std::ostringstream oss;
    std::copy(result.begin(), result.end() - 1, std::ostream_iterator<std::string>(oss, " "));
    oss << *result.rbegin();
    return oss.str();
}

inline bool QueryEvaluator::test(const PKBQuery& query) {
	if (query.type == ClauseType::AFFECTS) {
		auto cached = cache_.find(query);
		if (cached != cache_.end()) {
			return cached->second;
		}
	}

	auto isNumber = [](const std::string& str) -> bool {
		return isdigit(*str.begin()) != 0;	//assume no string start with number
	};
	auto toNumber = [](const std::string& str) -> unsigned int {
		return static_cast<unsigned int>(std::stoul(str));
	};
	
	bool result = false;
	switch (query.type)
	{
	case ClauseType::USES:
		if (isNumber(query.left)) {
			result = pkb.isUsesS(toNumber(query.left), query.right);
		} else {
			result = pkb.isUsesP(query.left, query.right);
		}
		break;
	case ClauseType::MODIFIES:
		if (isNumber(query.left)) {
			result = pkb.isModifiesS(toNumber(query.left), query.right);
		}
		else {
			result = pkb.isModifiesP(query.left, query.right);
		}
		break;
	case ClauseType::FOLLOWS:
		result = pkb.isFollow(toNumber(query.left), toNumber(query.right), query.asterisk);
		break;
	case ClauseType::PARENT:
		result = pkb.isParent(toNumber(query.left), toNumber(query.right), query.asterisk);
		break;
	case ClauseType::CALLS:
		result = pkb.isCall(query.left, query.right, query.asterisk);
		break;
	case ClauseType::NEXT:
		result = pkb.isNext(toNumber(query.left), toNumber(query.right), query.asterisk);
		break;
	case ClauseType::AFFECTS:
		result = pkb.isAffect(toNumber(query.left), toNumber(query.right), query.asterisk);
		cache_[query] = result;
		break;
	case ClauseType::PATTERN:
		result = pkb.fitPattern(toNumber(query.left), query.right, query.pattern, query.patternUnderscore);
		break;
	case ClauseType::EQUAL:
		result = query.left == query.right;
		break;
	default:
		break;
	}
    
    return result;
}

void QueryEvaluator::initNodeWithArgType(DepNode& node, ArgType type) {
	switch (type)
	{
	case ArgType::ASSIGN:
		for (auto item : pkb.getAllAssign()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::CALL:
		for (auto item : pkb.getAllCall()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::CONSTANT:
		for (auto item : pkb.getAllConstant()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::IF:
		for (auto item : pkb.getAllIf()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::PROG_LINE:
		for (auto item : pkb.getAllStmt()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::PROCEDURE:
		node.domin.insert(pkb.getAllProc().begin(), pkb.getAllProc().end());
		break;
	case ArgType::STMT:
		for (auto item : pkb.getAllStmt()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::STMTLST:
		for (auto item : pkb.getAllStmtLst()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::VARIABLE:
		node.domin.insert(pkb.getAllVar().begin(), pkb.getAllVar().end());
		break;
	case ArgType::WHILE:
		for (auto item : pkb.getAllWhile()) {
			node.domin.insert(std::to_string(item));
		}
		break;
	case ArgType::BOOLEAN:
	case ArgType::NIL:
	default:
		break;
	}
}

inline void QueryEvaluator::clean() {
    selected_.clear();
    nodes_.clear();
	for (auto item : edges_) {
		delete item;
	}
    edges_.clear();
	cache_.clear();		//cannot carry to next query
}
