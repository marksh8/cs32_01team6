#pragma once
#include <iostream>
#include <string>
#include <limits>
#include <list>
#include <vector>
#include <regex>
#include "QueryEvaluator.h"
#include "utility.h"

// Parse query from string to Query objects
// Call process method in QueryEvaluator for processing
// and format QueryResult to string
class QueryParser
{
private:
	QueryEvaluator qp;

	std::string query;
	bool isValidQuery;
	std::string errorMsg;
	std::vector <Synonym> synonyms;
	std::vector <Synonym> selects;
	std::vector <Clause> clauses;

	int argTypeIndexCount;
	
public:
	QueryParser();
	~QueryParser();

	//call parseQuery then queryResult
	bool parseQuery(std::string);
	std::list<std::string> queryResult();

	bool DeclarationParsing(std::string);
	bool SelectParsing(std::string);
	bool RelationshipParsing(std::string);
	bool PatternParsing(std::string);
	bool AttributeParsing(std::string);

	//get set methods
	bool getIsValidQuery();
	std::string getQuery();
	std::string getErrorMsg();
	std::vector <Synonym> getSynonymList();
	std::vector <Synonym> getSelectList();
	std::vector <Clause> getClausesList();

	void setIsValidQuery(bool);

	bool isPresentInSynList(std::string);
	ArgType getSynTypeFromSynName(std::string);

	bool isValidAttrName(std::string, std::string);

	//Can be placed at Commons
	std::string trim(std::string, std::string);
	std::string extractFirstWord(std::string, std::string);
	std::string remainingAfterExtractFirstWord(std::string, std::string);
	std::string trimExcessSpaces(std::string);

	bool testRegex(std::string, std::string);
	
};

