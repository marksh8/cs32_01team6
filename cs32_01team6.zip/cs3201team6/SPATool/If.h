#pragma once
#include "Statement.h"
class If : public Statement
{
public:
	If(unsigned int line_number, Variable* control_var);
	~If();

	const Variable* control_var;
	virtual void addChild(Statement* child);
	bool fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore = false);
};
