#pragma once
#include "Statement.h"
class While : public Statement
{
public:
	While(unsigned int line_number, Variable* control_var);
	~While();

	const Variable* control_var;
	bool fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore = false);
};

