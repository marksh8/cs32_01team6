#pragma once
#include <string>
#include <map>

enum class ClauseType {
	USES, MODIFIES, FOLLOWS, PARENT, CALLS, NEXT, AFFECTS, PATTERN, EQUAL
};

enum class ArgType {
	ASSIGN, CALL, CONSTANT, IF, PROG_LINE, PROCEDURE, STMT, STMTLST, VARIABLE, WHILE, BOOLEAN, NIL
};

struct Synonym {
	std::string name;
	ArgType type = ArgType::NIL;

	void setType(std::string type);
};

bool operator==(const Synonym& lhs, const Synonym& rhs);
bool operator!=(const Synonym& lhs, const Synonym& rhs);
bool operator<(const Synonym& lhs, const Synonym& rhs);

struct Clause {
	Synonym arg1;
	Synonym arg2;

	ClauseType type;
	bool asterisk = false;
	Synonym patternSyn;
	bool patternUnderscore = false;

	void setType(std::string type);
};

bool operator==(const Clause& lhs, const Clause& rhs);
bool operator<(const Clause& lhs, const Clause& rhs);
