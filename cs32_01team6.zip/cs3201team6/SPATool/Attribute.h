#pragma once

// Reperesent atteribute (in with clause)
class Attribute
{
public:
	Attribute();
	~Attribute();
};

