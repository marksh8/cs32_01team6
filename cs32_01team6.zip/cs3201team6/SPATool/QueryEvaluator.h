#pragma once

#include "ProgramKnowledgeBase.h"

#include "utility.h"
#include <vector>
#include <set>
#include <string>
#include <unordered_map>
#include <queue>

struct PKBQuery {
    ClauseType type;
    bool asterisk;
    std::string left;   //value
    std::string right;
	bool patternUnderscore;
    std::string pattern;
};

bool operator==(const PKBQuery& lhs, const PKBQuery& rhs);

struct PKBQueryHash {
    size_t operator() (const PKBQuery& pkbQuery) const;
};

template <class T>
inline void hash_combine(std::size_t& seed, const T& v);

struct DepEdge {
    ClauseType type;
    bool asterisk;
    std::string left;   //node
    std::string right;
	bool patternUnderscore;
    std::string pattern;    //pattern string (second arg for pattern)
};

struct DepNode {
    std::set<std::string> domin;
    //bool: true if self on left
    std::set<std::pair<DepEdge*, bool>> deps;
};

class QueryEvaluator {
public:
	QueryEvaluator();
	~QueryEvaluator();
    std::list<std::string> process(const std::vector<Synonym>& selected, const std::vector<Clause>& clauses);
    
private:
	ProgramKnowledgeBase& pkb;

    typedef std::unordered_map<std::string, std::set<std::string>> ValueMap;
    
    const std::list<std::string> none_result;
    const std::list<std::string> false_result = {"false"};
    const std::list<std::string> true_result = {"true"};
    
    std::vector<DepEdge*> edges_;
    std::unordered_map<std::string, DepNode> nodes_;
    std::vector<std::string> selected_;
    
    std::unordered_map<PKBQuery, bool, PKBQueryHash> cache_;
    
    void recursiveSearch(std::list<std::string>& results, const ValueMap& remaining_values, unsigned int level);
    void stackSearch(std::list<std::string>& results);
    void addSelected(const std::vector<Synonym>& syns);
    void addEdges(const std::vector<Clause>& clauses);
    
    bool setAndReduceValues(ValueMap& values, const std::string& node, const std::string& value);
    bool checkLeft(DepEdge* edge, std::set<std::string>& left, std::set<std::string>& right);
    bool checkRight(DepEdge* edge, std::set<std::string>& left, std::set<std::string>& right);
    
    inline std::string wrapResult(const std::vector<std::string>& result) const;
    inline bool test(const PKBQuery& query);
    inline void initNodeWithArgType(DepNode& node, ArgType type);
    inline void clean();
};
