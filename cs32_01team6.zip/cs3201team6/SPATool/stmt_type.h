#pragma once
namespace stmt_type
{
	enum stmt_type { type_assign, type_call, type_while, type_if, type_any };
}
