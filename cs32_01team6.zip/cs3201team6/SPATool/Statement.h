#pragma once
#include <vector>
#include <set>
#include "Variable.h"
#include "stmt_type.h"

// Statement in the tree of ProgramKnowledgeDatabase
// *Should have parent/child method
// *Passed to QueryEvaluator when requested (by constant reference)
class Variable;
class Procedure;

class Statement
{
public:
	Statement(unsigned int line_number);
	~Statement();
	const unsigned int line_number;
	const std::string name;
	stmt_type::stmt_type type;
	//enum stmt_type { type_assign, type_call, type_while, type_if, type_any };
	//stmt_type type;
	bool isSelfInElse = false;
	bool isNextChildInElse = false;
	unsigned int firstElseChildNumber;
	unsigned int firstElseChildIndex;

	Procedure* root_procedure;
	Statement* parent;
	std::vector<Statement*> ancestors;
	Statement* leftSibling;
	Statement* rightSibling;
	std::vector<Statement*> childList;
	std::vector<Statement*> prev;
	Statement* next[2];

	std::set<Variable*> usedVars;
	std::set<Variable*> modifiedVars;

	static void addNextToIfRightSibling(Statement* If, Statement* rs);
	virtual void addChild(Statement* child);
	void addToUse(Variable* varName);
	void addToModify(Variable* varName);

	std::set<std::string> getAllUsesVar();
	std::set<std::string> getAllModifiesVar();

	//Queries
	bool ifUse(Variable* var);
	bool ifModify(Variable* var);

	//Note: strings WILL be modified
	virtual bool fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore = false);
};

