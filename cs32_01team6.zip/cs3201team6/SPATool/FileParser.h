//
//  FileParser.hpp
//  testcpp
//
//  Created by Shaohuai Luo on 24/2/16.
//  Copyright © 2016 Shaohuai Luo. All rights reserved.
//

#pragma once

#include "ProgramKnowledgeBase.h"

#include <string>
#include <vector>
#include <stack>
#include <fstream>

class FileParser {
public:
    FileParser(const std::string& file);
    ~FileParser();
    void parse(int startLine = 1);
    
private:
	ProgramKnowledgeBase& pkb;

    int lineNum = 0;
    int braceStack = 0;
    std::stack<bool> ifStack;
    bool hasStmtCurContainer = false;
    bool expectLeftBrace = false;
    bool expectElse = false;
    std::ifstream fileIn;
    
    void parseLine(const std::string& line);
    bool match_assign(std::vector<std::string>& line);
    bool match_if(std::vector<std::string>& line);
    bool match_while(std::vector<std::string>& line);
    bool match_call(std::vector<std::string>& line);
    bool match_proc(std::vector<std::string>& line);
    void clear_misc(std::vector<std::string>& line);
    
    void testName(const std::string& name);
    
    void error(const std::string& msg = "unknown error");
    
    void addAssign(std::string var,
		std::set<std::string> expvars, std::string expression, std::set<unsigned int> consts);
    void addWhile(std::string control_var);
    void addCall(std::string proc);
    void addIf(std::string control_var);
    void addProc(std::string name);
    void closeBrace();
    void beginElse();
};
