#include "Variable.h"



Variable::Variable(std::string name) : name(name)
{
}


Variable::~Variable()
{
}

void Variable::addToModify(Statement * stmt)
{
	modifiedStmt.insert(stmt);
}

void Variable::addToModify(Procedure * proc)
{
	modifiedProc.insert(proc);
}

void Variable::addToUse(Statement * stmt)
{
	usedStmt.insert(stmt);
}

void Variable::addToUse(Procedure * proc)
{
	usedProc.insert(proc);
}

bool Variable::ifUsedIn(Statement * stmt)
{
	return usedStmt.find(stmt) != usedStmt.end();
	
}

bool Variable::ifUsedIn(Procedure * proc)
{
	return usedProc.find(proc) != usedProc.end();
}

bool Variable::ifModifiedBy(Statement * stmt)
{
	return modifiedStmt.find(stmt) != modifiedStmt.end();
}

bool Variable::ifModifiedBy(Procedure * proc)
{
	return modifiedProc.find(proc) != modifiedProc.end();
}

std::set<unsigned int> Variable::getAllModifiesStmt(stmt_type::stmt_type type)
{
	std::set<unsigned int> result;
	for (std::set<Statement*>::iterator it = modifiedStmt.begin(); it != modifiedStmt.end(); ++it)
	{
		if ((*it)->type == type || type == stmt_type::type_any)
		{
			result.insert((*it)->line_number);
		}
	}

	return result;
}

std::set<unsigned int> Variable::getAllUsesStmt(stmt_type::stmt_type type)
{
	std::set<unsigned int> result;
	for (std::set<Statement*>::iterator it = usedStmt.begin(); it != usedStmt.end(); ++it)
	{
		if ((*it)->type == type || type == stmt_type::type_any)
		{
			result.insert((*it)->line_number);
		}
	}

	return result;
}

std::set<std::string> Variable::getAllModifiesProc()
{
	std::set<std::string> result;
	for (std::set<Procedure*>::iterator it = modifiedProc.begin(); it != modifiedProc.end(); ++it)
	{
		result.insert((*it)->name);
	}
	return result;
}

std::set<std::string> Variable::getAllUsesProc()
{
	std::set<std::string> result;
	for (std::set<Procedure*>::iterator it = usedProc.begin(); it != usedProc.end(); ++it)
	{
		result.insert((*it)->name);
	}
	return result;
}
