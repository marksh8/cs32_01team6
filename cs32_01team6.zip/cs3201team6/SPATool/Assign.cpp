#include "Assign.h"
#include <regex>
#include <algorithm>
#include <sstream>
#include <vector>

Assign::Assign(unsigned int line_number, Variable* variable, const std::string& expression) :Statement(line_number), variable(variable), expression(compressExpression(expression))
{
	type = stmt_type::type_assign;
}

Assign::~Assign()
{

}

bool Assign::fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore)
{
	if (patternStr1 != variable->name) {
		return false;
	}
	if (patternStr2 == "_") {
		return true;
	}
	if (assignUnderscore) {
		return expression.find(compressExpression(patternStr2)) != std::string::npos;
	}
	else {
		return expression == compressExpression(patternStr2);
	}
}

std::string Assign::compressTerm(const std::string& term)
{
	std::regex regexpr("[*]");
	auto it = std::sregex_iterator(term.begin(), term.end(), regexpr);
	auto it_end = std::sregex_iterator();

	std::size_t pre = 0;
	auto frontBrackets = std::string();
	auto midStr = std::string();
	if (it == it_end) {
		return "(" + term + ")";
	}
	else {
		auto pos = it->position();
		frontBrackets += "(";
		midStr += term.substr(pre, pos - pre);
		pre = pos;
		++it;
	}

	while (it != it_end) {
		auto pos = it->position();
		frontBrackets += '(';
		midStr += "*" + term.substr(pre + 1, pos - pre - 1) + ")";
		pre = pos;
		++it;
	}
	return frontBrackets + midStr + "*" + term.substr(pre + 1) + ")";
}

std::string Assign::compressExpr(const std::string& expr)
{
	std::regex regexpr("[+-]");
	auto it = std::sregex_iterator(expr.begin(), expr.end(), regexpr);
	auto it_end = std::sregex_iterator();

	std::size_t pre = 0;
	auto frontBrackets = std::string();
	auto midStr = std::string();
	if (it == it_end) {
		return compressTerm(expr);
	}
	else {
		auto pos = it->position();
		frontBrackets += '(';
		midStr += compressTerm(expr.substr(pre, pos - pre));
		pre = pos;
		++it;
	}

	while (it != it_end) {
		auto pos = it->position();
		frontBrackets += '(';
		midStr += expr.at(pre) + compressTerm(expr.substr(pre + 1, pos - pre - 1)) + ')';
		pre = pos;
		++it;
	}
	return frontBrackets + midStr + expr.at(pre) + compressTerm(expr.substr(pre + 1)) + ')';
}

std::string Assign::markerWithInt(int id) {
	auto marker_oss = std::ostringstream();
	marker_oss << "%" << id << "%";
	return marker_oss.str();
}

bool Assign::isMarker(std::string& str) {
	auto reg = std::regex("^%\\d+%$");
	return std::regex_match(str, reg);
}

std::string Assign::compressBracket(std::string& expr)
{
	int curCount = 0;
	auto res = std::vector<std::string>();
	auto right = expr.find(')');
	while (right != std::string::npos) {
		auto left = expr.substr(0, right).find_last_of('(');
		auto inner = expr.substr(left + 1, right - left - 1);
		if (isMarker(inner)) {
			expr.replace(left, right - left + 1, inner);    //remove redundant bracket
		}
		else {
			auto cexpr = compressExpr(inner);
			if (!cexpr.empty() && cexpr.front() == '(' && cexpr.back() == ')') {
				cexpr = cexpr.substr(1, cexpr.length() - 2);
			}
			res.push_back(cexpr);
			expr.replace(left, right - left + 1, markerWithInt(curCount++));
		}
		right = expr.find(')');
	}
	if (!isMarker(expr)) {
		res.push_back(compressExpr(expr));
		expr = markerWithInt(curCount++);
	}
	while (--curCount >= 0) {
		auto marker = markerWithInt(curCount);
		expr.replace(expr.find(marker), marker.length(), res[curCount]);
	}
	return expr;
}
std::string Assign::compressExpression(const std::string& expr) {
	auto exp = expr;
	exp.erase(std::remove_if(exp.begin(), exp.end(), ::isspace), exp.end());	//remove spaces
	auto compressed = compressBracket(exp);
	return compressed;
}



