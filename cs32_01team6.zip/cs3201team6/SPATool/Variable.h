#pragma once
#include <string>
#include <set>
#include "stmt_type.h"
#include "Statement.h"
#include "Procedure.h"

class Statement;
class Procedure;

class Variable
{
public:
	Variable(std::string name);
	~Variable();
	
	const std::string name;

	void addToModify(Statement* stmt);
	void addToModify(Procedure* proc);
	void addToUse(Statement* stmt);
	void addToUse(Procedure* proc);

	bool ifUsedIn(Statement* stmt);
	bool ifUsedIn(Procedure* proc);
	bool ifModifiedBy(Statement* stmt);
	bool ifModifiedBy(Procedure* proc);
	
	std::set<unsigned int> getAllModifiesStmt(stmt_type::stmt_type type);
	std::set<unsigned int> getAllUsesStmt(stmt_type::stmt_type type);
	std::set<std::string> getAllModifiesProc();
	std::set<std::string> getAllUsesProc();
	
private:
	std::set<Statement*> modifiedStmt;
	std::set<Procedure*> modifiedProc;
	std::set<Statement*> usedStmt;
	std::set<Procedure*> usedProc;

};

