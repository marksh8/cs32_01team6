#include "If.h"
#include <iostream>

If::If(unsigned int line_number, Variable* control_var) : Statement(line_number), control_var(control_var)
{
	type = stmt_type::type_if;
	firstElseChildNumber = 0;
	firstElseChildIndex = 0;
}

If::~If()
{
}

void If::addChild(Statement* child) //override
{
	child->isSelfInElse = isNextChildInElse;
	if (child->isSelfInElse)
	{
		child->parent = this;
		if (firstElseChildNumber == 0)
		{
			firstElseChildNumber = child->line_number;
			this->next[1] = child;
			child->prev.push_back(this);
		}
		else
		{
			child->leftSibling = childList.back();
			childList.back()->rightSibling = child;
			if (child->leftSibling->type == stmt_type::type_if) {
				addNextToIfRightSibling(child->leftSibling, child);
			}
			else {
				child->leftSibling->next[0] = child;
				child->prev.push_back(child->leftSibling);
			}
		}
		childList.push_back(child);
	}
	else
	{
		Statement::addChild(child);
	}
}

bool If::fitPattern(const std::string& patternStr1, const std::string& patternStr2, bool assignUnderscore)
{
	return patternStr1 == control_var->name;
}
