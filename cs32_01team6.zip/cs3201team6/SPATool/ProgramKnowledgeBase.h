#pragma once
#include <string>
#include <vector>
#include <unordered_map>
#include <set>
#include "Procedure.h"
#include "stmt_type.h"
#include "Assign.h"
#include "While.h"
#include "Call.h"
#include "If.h"

// Main model class
// Contain data for one program
// Contain list of procedures, each procedure represent a tree of statements
class ProgramKnowledgeBase
{
public:
	//Singleton design
	//Call getInstance to get a instance of the class
	//Lazy initialization, will correctly destroyed
	static ProgramKnowledgeBase& getInstance();
	ProgramKnowledgeBase(ProgramKnowledgeBase const&) = delete;
	void operator=(ProgramKnowledgeBase const&) = delete;
	~ProgramKnowledgeBase();
	void clean();
	
	void addProcedure(const std::string& name);
	void addAssign(const std::string& var, const std::set<std::string>& expvars, const std::string& expression, const std::set<unsigned int>& consts = std::set<unsigned int>());
	void addCall(const std::string& callee);
	void addWhile(const std::string& control_var);
	void addIf(const std::string& control_var);
	void beginElse(); //the following stmts until right bracket is in else branch of current container
	void rightBracket();

	// Queries
	const std::set<std::string>& getAllProc();
	const std::set<unsigned int>& getAllCall();
	const std::set<unsigned int>& getAllAssign();
	const std::set<unsigned int>& getAllWhile();
	const std::set<unsigned int>& getAllIf();
	const std::set<unsigned int>& getAllStmt();
	const std::set<unsigned int>& getAllStmtLst();
	const std::set<std::string>& getAllVar();
	const std::set<unsigned int>& getAllConstant();

	bool isFollow(unsigned int pre, unsigned int cur, bool asterisk = false);
	bool isFollowS(unsigned int pre, unsigned int cur);
	bool isParent(unsigned int parent, unsigned int child, bool asterisk = false);
	bool isParentS(unsigned int parent, unsigned int child);
	bool isUsesP(const std::string& proc, const std::string& var);
	bool isModifiesP(const std::string& proc, const std::string& var);
	bool isUsesS(unsigned int stmt, const std::string& var);
	bool isModifiesS(unsigned int stmt, const std::string& var);
	bool isNext(unsigned int pre, unsigned int cur, bool asterisk = false);
	bool isNextS(unsigned int pre, unsigned int cur);
	bool isAffect(unsigned int pre, unsigned int cur, bool asterisk = false);
	bool isAffectS(unsigned int pre, unsigned int cur);
	bool isCall(const std::string& caller, const std::string& callee, bool asterisk = false);
	bool isCallS(const std::string& caller, const std::string& callee);

	std::set<unsigned int> allStmtUses(std::string var, stmt_type::stmt_type type);
	std::set<unsigned int> allStmtModifies(std::string var, stmt_type::stmt_type type);
	std::set<std::string> allProcUses(std::string var);
	std::set<std::string> allProcModifies(std::string var);
	std::set<std::string> allVarUsesP(std::string proc);
	std::set<std::string> allVarModifiesP(std::string proc);
	std::set<std::string> allVarUsesS(unsigned int stmt);
	std::set<std::string> allVarModifiesS(unsigned int stmt);
	std::set<std::string> allCallers(std::string proc);
	std::set<std::string> allCallees(std::string proc);
	std::set<std::string> allDirectCallers(std::string proc);
	std::set<std::string> allDirectCallees(std::string proc);
	std::set<unsigned int> allNextStmts(unsigned int stmt);
	std::set<unsigned int> allPrevStmts(unsigned int stmt);
	std::set<unsigned int> allNextSStmts(unsigned int stmt);
	std::set<unsigned int> allPrevSStmts(unsigned int stmt);
	std::set<unsigned int> allAffectStmts(unsigned int stmt);
	std::set<unsigned int> allAffectedStmts(unsigned int stmt);
	std::set<unsigned int> allAffectSStmts(unsigned int stmt);
	std::set<unsigned int> allAffectedSStmts(unsigned int stmt);
	
	//for debug only
	std::string printStringSet(std::set<std::string>& set);
	std::string printIntSet(std::set<unsigned int>& set);

	bool fitPattern(unsigned int line, const std::string& patternStr1, const std::string& patternStr2, bool assignUnderScore = false);

	//allow modification
	void filterByPattern(std::set<unsigned int>& stmtSet, std::string patternStr1, std::string patternStr2, bool assignUnderScore);

private:
	ProgramKnowledgeBase();
	void addNode(Statement* s);

	unsigned int current_line;
	std::unordered_map<std::string, Procedure*> procIndex;
	std::vector<Statement*> stmtTable;
	std::unordered_map<std::string, Variable*> varTable;

	std::set<std::string> procs;
	std::set<unsigned int> assigns;
	std::set<unsigned int> ifstmts;
	std::set<unsigned int> whiles;
	std::set<unsigned int> stmts;
	std::set<unsigned int> stmtLsts;
	std::set<std::string> vars;
	std::set<unsigned int> constants;
	std::set<unsigned int> calls;

	Procedure* current_procedure;
	void associateStmtAndVarUses(Statement* stmt, std::string var);
	void associateStmtAndVarModifies(Statement* stmt, std::string var);
};

