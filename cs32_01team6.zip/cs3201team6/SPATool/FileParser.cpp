//
//  FileParser.cpp
//  testcpp
//
//  Created by Shaohuai Luo on 24/2/16.
//  Copyright © 2016 Shaohuai Luo. All rights reserved.
//

#include "FileParser.h"

#include <iostream>
#include <set>
#include <regex>

FileParser::FileParser(const std::string& file) : pkb(ProgramKnowledgeBase::getInstance()) {
    fileIn = std::ifstream(file);
    std::cout << file << fileIn.is_open() << std::endl;
}

FileParser::~FileParser() {
    
}

void FileParser::parse(int startLine) {
    std::string line;
    
    for(int i=1; i < startLine; ++i) {
        fileIn.ignore(std::numeric_limits<std::streamsize>::max(),'\n'); //ignore one line
    }
    
    lineNum = startLine;
    
    while (std::getline(fileIn, line)) {
        std::cout<< "new line: " << line <<std::endl;
        parseLine(line);
        ++lineNum;
    }
    if (braceStack != 0) {
        error("expected }");
    }
}

void FileParser::parseLine(const std::string& str) {
    auto line = std::vector<std::string>();
    bool hasStmt = false;
    auto reg = std::regex("[^a-zA-z0-9]");	//not number or letter
    auto regIt = std::sregex_iterator(str.begin(), str.end(), reg);
    auto itEnd = std::sregex_iterator();
    std::size_t pre = 0;
    while (regIt != itEnd) {
        auto cur = regIt->position();
        
		auto is_space = regIt->str() == " " || regIt->str() == "\t";

		if (cur - pre <= 0) { //if no word between
			//skip spaces
			if (is_space) {
				pre = cur + 1;
				++regIt;
				continue;
			}
		} else {
			auto word = str.substr(pre, cur - pre);
			line.push_back(word);
		}
        
        clear_misc(line);
		match_proc(line);
        if (!line.empty() && !hasStmt) {
            if (match_while(line) || match_if(line)) {
                if (braceStack == 0) {
                    error("stmt outside proc");
                }
                
                hasStmt = true;
                hasStmtCurContainer = true;
            }
        }
		
		if (!is_space) {
			line.push_back(regIt->str());
		}

		if (!line.empty() && !hasStmt) {
			if (match_call(line) || match_assign(line)) {
				if (braceStack == 0) {
					error("stmt outside proc");
				}

				hasStmt = true;
				hasStmtCurContainer = true;
			}
		}
        
        pre = cur + 1;  //ignore the char found
        ++regIt;
    }
    auto cur = str.length();
    if (cur - pre > 0) {	//is a word at last
        auto word = str.substr(pre, cur - pre);
        line.push_back(word);
    }

	clear_misc(line);
	match_proc(line);
	if (!line.empty() && !hasStmt) {
		if (match_while(line) || match_if(line)) {
			if (braceStack == 0) {
				error("stmt outside proc");
			}

			hasStmt = true;
			hasStmtCurContainer = true;
		}
	}
    
    if (!line.empty()) {
        error("unable to process");
    }
}

bool FileParser::match_assign(std::vector<std::string>& line) {
    if (line.size() < 4 || line.back() != ";") {
        return false;
    }
    
    line.pop_back();    //remove ;
    
    auto i = line.begin();
    auto var = *i;
    testName(var);
    if (*(++i) != "=") {
        return false;
    }

    std::set<std::string> exprVars;
    std::set<unsigned int> constants;
    std::string expStr;
    bool lastIsOp = true;
    int localBracketStack = 0;
    auto pre = i;
    while (++i != line.end()) {
        expStr += *i;
        if (*i == "+" || *i == "-" || *i == "*") {
            if (lastIsOp) {
                error("invalid expr");
            }
            lastIsOp = true;
        }
        else if (*i == "(") {
            if (!lastIsOp) {
                error("invalid expr");
            }
            ++localBracketStack;
            lastIsOp = true;
        }
        else if (*i == ")") {
            --localBracketStack;
            if (lastIsOp || localBracketStack < 0) {
                error("invalid expr");
            }
            lastIsOp = false;
        }
        else {
            if (!lastIsOp) {
                error("invalid expr");
            }
            if (std::find_if_not(i->begin(), i->end(), isdigit) == i->end()) {
                constants.insert(std::stoi(*i));
            }
            else {
                testName(*i);
                exprVars.insert(*i);
            }
            lastIsOp = false;
        }
        pre = i;
    }
    line.clear();
    addAssign(var, exprVars, expStr, constants);
    return true;
}

bool FileParser::match_if(std::vector<std::string>& line) {
    if (line.size() != 3) {
        return false;
    }
    
    if (line[0] == "if" && line[2] == "then") {
        auto var = line[1];
        testName(var);
        
        addIf(var);
        expectLeftBrace = true;
        ifStack.push(true);
        line.clear();
		return true;
    }
    
    return false;
}

bool FileParser::match_while(std::vector<std::string>& line) {
    if (line.size() != 2) {
        return false;
    }
    
    if (line[0] == "while") {
        auto var = line[1];
        testName(var);
        
        addWhile(var);
        ifStack.push(false);
        expectLeftBrace = true;
        line.clear();
		return true;
    }
    
	return false;
}

bool FileParser::match_call(std::vector<std::string>& line) {
    if (line.size() != 3) {
        return false;
    }
    
    if (line[0] == "call" && line[2] == ";") {
        auto var = line[1];
        testName(var);
        
        addCall(var);
        line.clear();
		return true;
    }
    
    return false;
}

bool FileParser::match_proc(std::vector<std::string>& line) {
    if (line.size() != 2) {
        return false;
    }
    
    if (line[0] == "procedure") {
        auto var = line[1];
		if (braceStack != 0) {
			error("unexpected procedure");
		}
        testName(var);
        
        addProc(var);
        ifStack.push(false);
        expectLeftBrace = true;
        line.clear();
		return true;
    }
    
    return false;
}

void FileParser::clear_misc(std::vector<std::string>& line) {
    auto it = line.begin();
    
    while (it != line.end()) {
        //left brace
        if (expectLeftBrace) {
            if (*it == "{") {
                it = line.erase(it);
                expectLeftBrace = false;
                ++braceStack;
                hasStmtCurContainer = false;
                continue;
            } else {
                error("expected '{'");
            }
        }
        
        //right brace
        if (*it == "}" && braceStack > 0) {
            it = line.erase(it);
			closeBrace();
            if (!hasStmtCurContainer) {
                error("empty container");
            }
            if (!ifStack.empty()) {
                if (ifStack.top()) {
                    expectElse = true;
                }
                ifStack.pop();
            }
            --braceStack;
            continue;
        }
        
        //else
        if (expectElse) {
            if (*it == "else") {
                it = line.erase(it);
				beginElse();
				ifStack.push(false);
                expectElse = false;
                expectLeftBrace = true;
                continue;
            } else {
                error("expected 'else'");
            }
        }
        
        ++it;
    }
}

void FileParser::testName(const std::string& name) {
    if (name.empty()) {
        error("invalid var name");
    }
    if (std::isdigit(name[0], std::locale())) {
        error("invalid var name");
    }
    
    auto res = find_if_not(name.begin(), name.end(), isalnum) == name.end();
    if (!res) {
        error("invalid var name");
    }
}

void FileParser::error(const std::string& msg) {
    std::cout << "ERROR at line " << lineNum << ": " << msg <<std::endl;
    exit(0);
}

void FileParser::addAssign(std::string var,
	std::set<std::string> expvars, std::string expression, std::set<unsigned int> consts) {
	pkb.addAssign(var, expvars, expression, consts);
}

void FileParser::addWhile(std::string control_var) {
	pkb.addWhile(control_var);
}

void FileParser::addCall(std::string proc) {
	pkb.addCall(proc);
}

void FileParser::addIf(std::string control_var) {
	pkb.addIf(control_var);
}

void FileParser::addProc(std::string name) {
	pkb.addProcedure(name);
}

void FileParser::closeBrace() {
	pkb.rightBracket();
}

void FileParser::beginElse() {
	pkb.beginElse();
}
