#include "Procedure.h"



Procedure::Procedure(const std::string& name) : name(name)
{
	current_container = nullptr;
}


Procedure::~Procedure()
{
	for (Statement* child : childList)
	{
		delete child;
	}
}

void Procedure::addChild(Statement* child)
{
	child->root_procedure = this;
	if (current_container == nullptr)
	{
		if (!childList.empty())
		{
			child->leftSibling = childList.back();
			childList.back()->rightSibling = child;
			if (child->leftSibling->type != stmt_type::type_if)
			{
				if (child->leftSibling->type == stmt_type::type_while)
				{
					child->leftSibling->next[1] = child;
				}
				else
				{
					child->leftSibling->next[0] = child;
				}
				child->prev.push_back(child->leftSibling);
			}
			else
			{
				Statement::addNextToIfRightSibling(child->leftSibling, child);
			}
		}

		childList.push_back(child);
	}
	else
	{
		current_container->addChild(child);
	}
}

void Procedure::addToUse(Variable * varName)
{
	usedVars.insert(varName);
	varName->addToUse(this);
	for (auto i = callerStack.begin(); i != callerStack.end(); ++i)
	{
		(*i)->usedVars.insert(varName);
		varName->addToUse(*i);
	}
	for (auto i = callerStmts.begin(); i != callerStmts.end(); ++i)
	{
		(*i)->addToUse(varName);
	}
}

void Procedure::addToModify(Variable * varName)
{
	modifiedVars.insert(varName);
	varName->addToModify(this);
	for (auto i = callerStack.begin(); i != callerStack.end(); ++i)
	{
		(*i)->modifiedVars.insert(varName);
		varName->addToModify(*i);
	}
	for (auto i = callerStmts.begin(); i != callerStmts.end(); ++i)
	{
		(*i)->addToModify(varName);
	}
}

void Procedure::addCaller(Procedure * caller)
{
	callerStack.insert(caller);
}

void Procedure::addCallerStmt(Statement * stmt)
{
	callerStmts.insert(stmt);
}

void Procedure::addCallee(Procedure * callee)
{
	calleeStack.insert(callee);
}

void Procedure::addDirectCaller(Procedure * caller)
{
	directCallers.insert(caller);
}

void Procedure::addDirectCallee(Procedure * callee)
{
	directCallees.insert(callee);
}

std::set<std::string> Procedure::getAllUsesVar()
{
	std::set<std::string> result;
	for (std::set<Variable*>::iterator it = usedVars.begin(); it != usedVars.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

std::set<std::string> Procedure::getAllModifiesVar()
{
	std::set<std::string> result;
	for (std::set<Variable*>::iterator it = modifiedVars.begin(); it != modifiedVars.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

std::set<std::string> Procedure::getAllCallers()
{
	std::set<std::string> result;
	for (auto it = callerStack.begin(); it != callerStack.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

std::set<std::string> Procedure::getAllCallees()
{
	std::set<std::string> result;
	for (auto it = calleeStack.begin(); it != calleeStack.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

std::set<std::string> Procedure::getAllDirectCallers()
{
	std::set<std::string> result;
	for (auto it = directCallers.begin(); it != directCallers.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

std::set<std::string> Procedure::getAllDirectCallees()
{
	std::set<std::string> result;
	for (auto it = directCallees.begin(); it != directCallees.end(); it++)
	{
		result.insert((*it)->name);
	}
	return result;
}

bool Procedure::ifUse(Variable* var)
{
	return usedVars.find(var) != usedVars.end();
}

bool Procedure::ifModify(Variable* var)
{
	return modifiedVars.find(var) != modifiedVars.end();
}

bool Procedure::ifDirectCalledBy(Procedure * caller)
{
	if (directCallers.find(caller) == directCallers.end()) return false;
	else return true;
}

bool Procedure::ifDirectCall(Procedure * callee)
{
	if (directCallees.find(callee) == directCallees.end()) return false;
	else return true;
}

bool Procedure::ifCalledBy(Procedure * caller)
{
	if (callerStack.find(caller) == callerStack.end()) return false;
	else return true;
}

bool Procedure::ifCall(Procedure * callee)
{
	if (calleeStack.find(callee) == calleeStack.end()) return false;
	else return true;
}

