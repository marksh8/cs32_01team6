#pragma once
#include "Statement.h"

class Call : public Statement
{
public:
	Call(unsigned int line_number, Procedure* calleeName);
	~Call();

	const Procedure* calleeName;
};
