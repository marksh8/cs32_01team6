#include "utility.h"

bool operator==(const Synonym& lhs, const Synonym& rhs) {
    //assume no two synonym with same name
    return lhs.name == rhs.name;
}

bool operator!=(const Synonym& lhs, const Synonym& rhs) {
    return !(lhs == rhs);
}

bool operator<(const Synonym& lhs, const Synonym& rhs) {
    //assume no two synonym with same name
    return lhs.name < rhs.name;
}

void Synonym::setType(std::string type) {
	const static std::map<std::string, ArgType>
		typeMap = { { "assign", ArgType::ASSIGN },
					{ "call", ArgType::CALL },
					{ "constant", ArgType::CONSTANT },
					{ "if", ArgType::IF },
					{ "prog_line", ArgType::PROG_LINE },
					{ "procedure", ArgType::PROCEDURE },
					{ "stmt", ArgType::STMT },
					{ "stmtlst", ArgType::STMTLST },
					{ "variable", ArgType::VARIABLE },
					{ "while", ArgType::WHILE },
					{ "BOOLEAN", ArgType::BOOLEAN } };

	//warning: throw exception if not exist
	this->type = typeMap.at(type);
}

bool operator==(const Clause& lhs, const Clause& rhs) {
    return lhs.type == rhs.type && lhs.arg1 == rhs.arg1 && lhs.arg2 == rhs.arg2;
}

bool operator<(const Clause& lhs, const Clause& rhs) {
    return std::tie(lhs.type, lhs.arg1, lhs.arg2) < std::tie(rhs.type, rhs.arg1, rhs.arg2);
}

void Clause::setType(std::string type) {
	const static std::map<std::string, ClauseType>
		typeMap = { { "Uses", ClauseType::USES },
					{ "Modifies", ClauseType::MODIFIES },
					{ "Follows", ClauseType::FOLLOWS },
					{ "Parent", ClauseType::PARENT },
					{ "Calls", ClauseType::CALLS },
					{ "Next", ClauseType::NEXT },
					{ "Affects", ClauseType::AFFECTS },
					{ "pattern", ClauseType::PATTERN },
					{ "with", ClauseType::EQUAL } };

	//warning: throw exception if not exist
	this->type = typeMap.at(type);
}

