#include "Call.h"

Call::Call(unsigned int line_number, Procedure* calleeName) : Statement(line_number), calleeName(calleeName)
{
	type = stmt_type::type_call;
}

Call::~Call()
{
}
