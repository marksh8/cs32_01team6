The project MUST be complied in x86 (32bit) environment (unknow error)

the exe file will be output to Debug folder in the root dir (Release untested)

